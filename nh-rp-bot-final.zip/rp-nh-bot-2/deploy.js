require('dotenv').config();
const { REST, Routes, SlashCommandBuilder } = require('discord.js');

const commands = [
    new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('🎫 Abre o painel de tickets')
        .toJSON()
];

const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);

(async () => {
    try {
        console.log('📝 Registrando comandos...');
        console.log('Token:', process.env.TOKEN ? 'OK' : 'FALTANDO');
        console.log('Client ID:', process.env.CLIENT_ID);
        console.log('Guild ID:', process.env.GUILD_ID);

        await rest.put(
            Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
            { body: commands }
        );

        console.log('✅ /ticket registrado!');
    } catch (error) {
        console.error('❌ Erro:', error.message);
    }
})();
