function validateColor(color) {
    if (!color) return false;
    return /^#([0-9A-Fa-f]{3}|[0-9A-Fa-f]{6})$/.test(color);
}

function validateUrl(url) {
    if (!url) return false;
    try {
        new URL(url);
        return true;
    } catch {
        return false;
    }
}

function validateEmoji(emoji) {
    if (!emoji) return false;
    const unicodeEmoji = /^[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}]+$/u;
    const customEmoji = /^<a?:\w+:\d+>$/;
    return unicodeEmoji.test(emoji) || customEmoji.test(emoji);
}

function extractId(mention) {
    if (!mention) return null;
    const match = mention.match(/\d+/);
    return match ? match[0] : null;
}

module.exports = { validateColor, validateUrl, validateEmoji, extractId };
