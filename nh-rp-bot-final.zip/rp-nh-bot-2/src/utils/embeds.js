const { EmbedBuilder } = require('discord.js');

const THEME = {
    primary: '#00FFFF',
    secondary: '#00CED1',
    success: '#00FF88',
    danger: '#FF0055',
    warning: '#FFB800',
    info: '#0099FF',
    purple: '#8A2BE2',
    dark: '#0a0a1a',
    gold: '#FFD700',
    pink: '#FF69B4'
};

// ==================== EMBEDS DE RESPOSTA ====================

function successReply(description) {
    return new EmbedBuilder()
        .setColor(THEME.success)
        .setDescription(`✅ **${description}**`)
        .setFooter({ text: 'NH RP • Sucesso' })
        .setTimestamp();
}

function errorReply(description) {
    return new EmbedBuilder()
        .setColor(THEME.danger)
        .setDescription(`❌ **${description}**`)
        .setFooter({ text: 'NH RP • Erro' })
        .setTimestamp();
}

function warningReply(description) {
    return new EmbedBuilder()
        .setColor(THEME.warning)
        .setDescription(`⚠️ **${description}**`)
        .setFooter({ text: 'NH RP • Atenção' })
        .setTimestamp();
}

function infoReply(description) {
    return new EmbedBuilder()
        .setColor(THEME.info)
        .setDescription(`ℹ️ **${description}**`)
        .setFooter({ text: 'NH RP • Informação' })
        .setTimestamp();
}

function permissionDenied() {
    return new EmbedBuilder()
        .setColor(THEME.danger)
        .setTitle('🔒 Acesso Negado')
        .setDescription('Você não possui o cargo de **Administrador** necessário para acessar este painel.')
        .setFooter({ text: 'NH RP • Segurança' })
        .setTimestamp();
}

// ==================== MENU PRINCIPAL ====================

function mainMenuEmbed(guildName, guildIcon) {
    return new EmbedBuilder()
        .setColor(THEME.primary)
        .setAuthor({ name: '🎫 Sistema de Tickets', iconURL: guildIcon || null })
        .setDescription(`# Bem-vindo ao painel de controle\n\n> Gerencie todo o sistema de tickets do **${guildName || 'servidor'}**.\n\n### 📌 Selecione uma opção:`)
        .setImage('https://cdn.discordapp.com/attachments/1350922977243304063/1525250927932604487/ChatGPT_Image_9_de_jul._de_2026_18_39_32.png')
        .addFields(
            { name: '⚡ Rápida', value: '```Cria @Staff, canais e painel\ncom 5 opções prontas.```', inline: true },
            { name: '🎨 Personalizada', value: '```Crie painéis do zero\ncom seu próprio design.```', inline: true },
            { name: '✏️ Editar', value: '```Edite painéis salvos\ne reenvie ao canal.```', inline: true },
            { name: '🗑️ Excluir', value: '```Remova painéis\npermanentemente.```', inline: true },
            { name: '📊 Estatísticas', value: '```Visualize métricas\ndo sistema de tickets.```', inline: true }
        )
        .setFooter({ text: 'NH RP © 2026 • v3.0 Premium', iconURL: guildIcon || null })
        .setTimestamp();
}

// ==================== PAINEL PREVIEW ====================

function panelPreviewEmbed(panel) {
    const embed = new EmbedBuilder()
        .setColor(panel?.color || THEME.primary)
        .setTimestamp();

    if (panel?.title) embed.setTitle(panel.title);
    if (panel?.description) embed.setDescription(panel.description);
    if (panel?.author_name) {
        embed.setAuthor({ name: panel.author_name, iconURL: panel.author_icon || null, url: panel.author_url || null });
    }
    if (panel?.footer_text) {
        embed.setFooter({ text: panel.footer_text, iconURL: panel.footer_icon || null });
    }
    if (panel?.thumbnail_url) embed.setThumbnail(panel.thumbnail_url);
    if (panel?.image_url) embed.setImage(panel.image_url);
    if (panel?.options && panel.options.length > 0) {
        const optList = panel.options.map(o => `${o.emoji} **${o.name}** — ${o.description || 'Sem descrição'}`).join('\n');
        embed.addFields({ name: '📋 Opções Disponíveis', value: optList });
    }

    return embed;
}

// ==================== TICKET EMBEDS ====================

function ticketClaimedEmbed(staff, userId, ticketId) {
    return new EmbedBuilder()
        .setColor(THEME.success)
        .setTitle('🙋 Ticket Assumido')
        .setDescription(`### O staff ${staff} assumiu o atendimento!\n\nAgora ele é o responsável por este ticket.`)
        .addFields(
            { name: '👤 Cliente', value: `<@${userId}>`, inline: true },
            { name: '👮 Staff', value: staff.toString(), inline: true },
            { name: '🎫 ID', value: '#' + (ticketId || '').substring(0, 8), inline: true }
        )
        .setFooter({ text: 'NH RP • Atendimento Iniciado' })
        .setTimestamp();
}

function ticketClosedEmbed(staff, userId, msgCount) {
    return new EmbedBuilder()
        .setColor(THEME.danger)
        .setTitle('🔒 Ticket Fechado')
        .setDescription(`### O ticket foi fechado com sucesso!\n\n📄 Transcript com **${msgCount || 0}** mensagens enviado na DM e no canal de logs.\n\n⏰ Canal será excluído em **5 segundos**.`)
        .addFields(
            { name: '👤 Cliente', value: `<@${userId}>`, inline: true },
            { name: '👮 Fechado por', value: staff.toString(), inline: true }
        )
        .setFooter({ text: 'NH RP • Obrigado pelo contato!' })
        .setTimestamp();
}

function ticketTransferredEmbed(fromStaff, toStaff) {
    return new EmbedBuilder()
        .setColor(THEME.warning)
        .setTitle('🔗 Ticket Transferido')
        .setDescription(`### O atendimento foi transferido com sucesso!`)
        .addFields(
            { name: '👮 De', value: fromStaff.toString(), inline: true },
            { name: '👮 Para', value: toStaff.toString(), inline: true }
        )
        .setFooter({ text: 'NH RP • Transferência' })
        .setTimestamp();
}

function ticketCreatedEmbed(panel, member, optName, ticketId) {
    const embed = new EmbedBuilder()
        .setColor(panel?.color || THEME.primary)
        .setTitle(`🎫 ${optName}`)
        .setDescription(panel?.welcome_message || `Olá ${member}!\n\nBem-vindo ao seu ticket de **${optName}**. Descreva seu problema abaixo e um staff irá atendê-lo em breve.`)
        .addFields(
            { name: '👤 Cliente', value: member.toString(), inline: true },
            { name: '📩 Tipo', value: optName, inline: true },
            { name: '🎫 ID', value: '#' + (ticketId || '').substring(0, 8), inline: true }
        )
        .setFooter({ text: 'NH RP • Aguarde o atendimento' })
        .setTimestamp();

    if (panel?.thumbnail_url) embed.setThumbnail(panel.thumbnail_url);
    if (panel?.image_url) embed.setImage(panel.image_url);

    return embed;
}

function ticketLogEmbed(user, optName, ticketId, channel) {
    return new EmbedBuilder()
        .setColor(THEME.primary)
        .setTitle('📝 Novo Ticket Aberto')
        .addFields(
            { name: '👤 Cliente', value: user.toString(), inline: true },
            { name: '📩 Tipo', value: optName, inline: true },
            { name: '📂 Canal', value: channel?.toString() || 'N/A', inline: true },
            { name: '🎫 ID', value: '#' + (ticketId || '').substring(0, 8), inline: true }
        )
        .setFooter({ text: 'NH RP • Sistema de Logs' })
        .setTimestamp();
}

// ==================== ESTATÍSTICAS ====================

function statsEmbed(todayOpen, todayClosed, totalOpen, totalClosed, avgRating, topStaff) {
    const embed = new EmbedBuilder()
        .setColor(THEME.gold)
        .setTitle('📊 Estatísticas de Tickets')
        .setDescription('### Resumo do sistema de atendimento')
        .addFields(
            { name: '📈 Hoje', value: `Abertos: **${todayOpen}**\nFechados: **${todayClosed}**`, inline: true },
            { name: '📊 Total', value: `Abertos: **${totalOpen}**\nFechados: **${totalClosed}**`, inline: true },
            { name: '⭐ Avaliação', value: `Média: **${avgRating}/5**`, inline: true }
        )
        .setFooter({ text: 'NH RP • Atualizado agora' })
        .setTimestamp();

    if (topStaff) {
        embed.addFields({ name: '🏆 Top Staff', value: topStaff, inline: false });
    }

    return embed;
}

// ==================== AVALIAÇÃO ====================

function ratingEmbed(user, rating, feedback) {
    const stars = '⭐'.repeat(rating) + '☆'.repeat(5 - rating);
    return new EmbedBuilder()
        .setColor(THEME.gold)
        .setTitle('⭐ Avaliação do Atendimento')
        .setDescription(`### ${stars}\n\n**Nota: ${rating}/5**`)
        .addFields(
            { name: '👤 Cliente', value: user?.toString() || 'Usuário', inline: true },
            { name: '💬 Feedback', value: feedback || 'Nenhum comentário', inline: false }
        )
        .setFooter({ text: 'NH RP • Satisfação do cliente' })
        .setTimestamp();
}

// ==================== EXPORTAÇÕES ====================

module.exports = {
    THEME,
    successReply,
    errorReply,
    warningReply,
    infoReply,
    permissionDenied,
    mainMenuEmbed,
    panelPreviewEmbed,
    ticketClaimedEmbed,
    ticketClosedEmbed,
    ticketTransferredEmbed,
    ticketCreatedEmbed,
    ticketLogEmbed,
    statsEmbed,
    ratingEmbed
};
