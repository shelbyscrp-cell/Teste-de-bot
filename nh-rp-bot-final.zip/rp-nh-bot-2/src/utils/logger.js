const winston = require('winston');
const path = require('path');
const fs = require('fs-extra');

const logsDir = path.join(process.env.HOME, 'rp-nh-bot-2', 'logs');
fs.ensureDirSync(logsDir);

const logger = winston.createLogger({
    level: 'info',
    format: winston.format.combine(
        winston.format.timestamp({ format: 'DD/MM/YYYY HH:mm:ss' }),
        winston.format.printf(({ timestamp, level, message }) => {
            return `${timestamp} [${level.toUpperCase()}]: ${message}`;
        })
    ),
    transports: [
        new winston.transports.File({ filename: path.join(logsDir, 'error.log'), level: 'error' }),
        new winston.transports.File({ filename: path.join(logsDir, 'combined.log') }),
        new winston.transports.Console()
    ]
});

module.exports = logger;
