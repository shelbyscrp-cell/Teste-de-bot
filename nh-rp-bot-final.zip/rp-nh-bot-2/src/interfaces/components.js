const { ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, EmbedBuilder } = require('discord.js');

// ==================== MENU PRINCIPAL ====================

function mainMenuRow() {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('quick_setup').setLabel('⚡ Rápida').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('custom_setup').setLabel('🎨 Personalizada').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('edit_panel_menu').setLabel('✏️ Editar').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('delete_panel_menu').setLabel('🗑️ Excluir').setStyle(ButtonStyle.Danger)
    );
}

function mainMenuRow2() {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('stats_menu').setLabel('📊 Estatísticas').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('back_to_main').setLabel('🔄 Atualizar').setStyle(ButtonStyle.Primary)
    );
}

function backToMainRow() {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('back_to_main').setLabel('⬅️ Voltar ao Menu').setStyle(ButtonStyle.Secondary)
    );
}

function quickSetupConfirmRow() {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('back_to_main').setLabel('⬅️ Cancelar').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId('quick_setup_confirm').setLabel('✅ Confirmar').setStyle(ButtonStyle.Success)
    );
}

// ==================== PAINEL PERSONALIZADO ====================

function customSetupRow(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`panel_title_${panelId}`).setLabel('📝 Título').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`panel_desc_${panelId}`).setLabel('📄 Descrição').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`panel_color_${panelId}`).setLabel('🎨 Cor').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`panel_author_${panelId}`).setLabel('👤 Autor').setStyle(ButtonStyle.Primary)
    );
}

function customSetupRow2(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`panel_image_${panelId}`).setLabel('🖼️ Imagem').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`panel_footer_${panelId}`).setLabel('📌 Rodapé').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`panel_options_${panelId}`).setLabel('➕ Opções').setStyle(ButtonStyle.Success)
    );
}

function customSetupRow3(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`panel_genconfig_${panelId}`).setLabel('⚙️ Gerais').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId(`panel_save_${panelId}`).setLabel('💾 Salvar').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId(`panel_send_${panelId}`).setLabel('📤 Enviar').setStyle(ButtonStyle.Primary)
    );
}

// ==================== MODAIS ====================

function titleModal(panelId, currentTitle, currentUrl) {
    return new ModalBuilder()
        .setCustomId(`modal_title_${panelId}`)
        .setTitle('📝 Editar Título')
        .addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('title').setLabel('Título').setPlaceholder('© SUPORTE NH-BOT').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(256).setValue(currentTitle || '')),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('title_url').setLabel('URL (opcional)').setPlaceholder('https://...').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(500).setValue(currentUrl || ''))
        );
}

function descriptionModal(panelId, currentDesc) {
    return new ModalBuilder()
        .setCustomId(`modal_desc_${panelId}`)
        .setTitle('📄 Editar Descrição')
        .addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('description').setLabel('Descrição').setPlaceholder('Bem-vindo ao suporte!').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(4000).setValue(currentDesc || '')));
}

function colorModal(panelId) {
    return new ModalBuilder()
        .setCustomId(`modal_color_${panelId}`)
        .setTitle('🌈 Informar Cor')
        .addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('color').setLabel('Código Hex').setPlaceholder('#00FFFF').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(7).setValue('#00FFFF')));
}

function authorModal(panelId, currentName, currentUrl, currentIcon) {
    return new ModalBuilder()
        .setCustomId(`modal_author_${panelId}`)
        .setTitle('👤 Editar Autor')
        .addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('author_name').setLabel('Nome').setPlaceholder('©Colt Programmer').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(256).setValue(currentName || '')),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('author_url').setLabel('URL (opcional)').setPlaceholder('https://...').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(500).setValue(currentUrl || '')),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('author_icon').setLabel('Ícone (URL)').setPlaceholder('https://...').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(500).setValue(currentIcon || ''))
        );
}

function imageModal(panelId, currentImage, currentThumb) {
    return new ModalBuilder()
        .setCustomId(`modal_image_${panelId}`)
        .setTitle('🖼️ Editar Imagens')
        .addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('image_url').setLabel('Imagem Principal (URL)').setPlaceholder('https://...').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(500).setValue(currentImage || '')),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('thumbnail_url').setLabel('Thumbnail (URL)').setPlaceholder('https://...').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(500).setValue(currentThumb || ''))
        );
}

function footerModal(panelId, currentText, currentIcon) {
    return new ModalBuilder()
        .setCustomId(`modal_footer_${panelId}`)
        .setTitle('📌 Editar Rodapé')
        .addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('footer_text').setLabel('Texto').setPlaceholder('Novo Horizonte Roleplay ©').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(2048).setValue(currentText || '')),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('footer_icon').setLabel('Ícone (URL)').setPlaceholder('https://...').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(500).setValue(currentIcon || ''))
        );
}

function panelNameModal(panelId, currentName) {
    return new ModalBuilder()
        .setCustomId(`modal_panel_name_${panelId}`)
        .setTitle('✏️ Nome do Painel')
        .addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('panel_name').setLabel('Nome').setPlaceholder('Suporte VIP').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100).setValue(currentName || '')));
}

function autoCloseInactiveModal(panelId, currentValue) {
    return new ModalBuilder()
        .setCustomId(`modal_autoclose_inactive_${panelId}`)
        .setTitle('⏱️ Inatividade')
        .addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('inactive_time').setLabel('Tempo (1d, 12h, 30m)').setPlaceholder('Deixe em branco para desativar').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(10).setValue(currentValue || '')));
}

function selectMessageModal(panelId) {
    return new ModalBuilder()
        .setCustomId(`modal_select_msg_${panelId}`)
        .setTitle('📝 Mensagem de Seleção')
        .addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('select_message').setLabel('Mensagem').setPlaceholder('Selecione uma opção...').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(150)));
}

// ==================== CORES ====================

function colorSelectRow(panelId) {
    return new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId(`select_color_${panelId}`).setPlaceholder('🎨 Selecione uma cor...').addOptions([
            { label: 'Vermelho', value: '#FF0000', emoji: '🔴' },
            { label: 'Laranja', value: '#FF8800', emoji: '🟠' },
            { label: 'Amarelo', value: '#FFEE00', emoji: '🟡' },
            { label: 'Verde', value: '#00FF00', emoji: '🟢' },
            { label: 'Azul', value: '#0000FF', emoji: '🔵' },
            { label: 'Roxo', value: '#8A2BE2', emoji: '🟣' },
            { label: 'Preto', value: '#1a1a1a', emoji: '⚫' },
            { label: 'Branco', value: '#FFFFFF', emoji: '⚪' },
            { label: 'Rosa', value: '#FF69B4', emoji: '🌸' },
            { label: 'Magenta', value: '#FF00FF', emoji: '🎀' },
            { label: 'Marrom', value: '#8B4513', emoji: '🟤' },
            { label: 'Ciano', value: '#00FFFF', emoji: '🧊' },
            { label: 'Dourado', value: '#FFD700', emoji: '⭐' },
            { label: 'Azul Claro', value: '#87CEEB', emoji: '💎' },
            { label: 'Verde Água', value: '#00FF88', emoji: '🌊' }
        ])
    );
}

function colorButtonRow(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`back_to_panel_${panelId}`).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId(`panel_color_modal_${panelId}`).setLabel('🌈 Informe a cor').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setLabel('🔍 Buscar cores').setStyle(ButtonStyle.Link).setURL('https://htmlcolorcodes.com/')
    );
}

// ==================== OPÇÕES ====================

function optionsSelectRow(panelId, options) {
    const opts = options.slice(0, 25).map(o => ({
        label: String(o.name).substring(0, 100),
        value: o.id,
        emoji: String(o.emoji || '💬').substring(0, 10),
        description: String(o.description || '').substring(0, 100)
    }));
    return new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId(`select_option_${panelId}`).setPlaceholder('📋 Selecione uma opção...').addOptions(opts.length > 0 ? opts : [{ label: 'Nenhuma', value: 'none', emoji: '❌' }])
    );
}

function optionsMainRow(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`back_to_panel_${panelId}`).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId(`option_msg_${panelId}`).setLabel('📝 Mensagem').setStyle(ButtonStyle.Primary)
    );
}

function optionsRow2(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`option_create_${panelId}`).setLabel('➕ Nova').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId(`option_order_${panelId}`).setLabel('🔄 Ordem').setStyle(ButtonStyle.Primary)
    );
}

function optionsRow3(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`option_edit_${panelId}`).setLabel('✏️ Editar').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`option_config_${panelId}`).setLabel('⚙️ Configurar').setStyle(ButtonStyle.Secondary)
    );
}

function optionsRow4(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`option_remove_${panelId}`).setLabel('🗑️ Remover').setStyle(ButtonStyle.Danger)
    );
}

function optionCreateModal(panelId, editId, currentEmoji, currentName, currentDesc) {
    return new ModalBuilder()
        .setCustomId(editId ? `modal_edit_option_${panelId}_${editId}` : `modal_create_option_${panelId}`)
        .setTitle(editId ? '✏️ Editar Opção' : '➕ Nova Opção')
        .addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('option_name').setLabel('Nome').setPlaceholder('Suporte').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(100).setValue(currentName || '')),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('option_emoji').setLabel('Emoji').setPlaceholder('💬').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(50).setValue(currentEmoji || '')),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('option_desc').setLabel('Descrição').setPlaceholder('Dúvidas e ajuda').setStyle(TextInputStyle.Paragraph).setRequired(false).setMaxLength(1000).setValue(currentDesc || ''))
        );
}

function optionOrderRow(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`option_move_up_${panelId}`).setLabel('⬆️ Subir').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`option_move_down_${panelId}`).setLabel('⬇️ Descer').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`back_to_options_${panelId}`).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary)
    );
}

function optionRemoveConfirmRow(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`back_to_options_${panelId}`).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId(`option_remove_confirm_${panelId}`).setLabel('🗑️ Confirmar').setStyle(ButtonStyle.Danger)
    );
}

// ==================== CONFIG GERAIS ====================

function generalConfigRow(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`back_to_panel_${panelId}`).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId(`genconfig_type_${panelId}`).setLabel('📍 Canal/Tópico').setStyle(ButtonStyle.Primary)
    );
}

function generalConfigRow2(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`genconfig_name_${panelId}`).setLabel('✏️ Nomear').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`genconfig_category_${panelId}`).setLabel('📂 Categoria').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`genconfig_logs_${panelId}`).setLabel('📄 Logs').setStyle(ButtonStyle.Primary)
    );
}

function generalConfigRow3(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`genconfig_topic_${panelId}`).setLabel('💬 Tópico').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`genconfig_userclose_${panelId}`).setLabel('🔒 Dono fechar').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`genconfig_extraroles_${panelId}`).setLabel('👥 Cargos Extra').setStyle(ButtonStyle.Primary)
    );
}

function generalConfigRow4(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`genconfig_autoclose_${panelId}`).setLabel('♻️ Auto close').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`genconfig_limit_${panelId}`).setLabel('🔢 Limitar').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`genconfig_ratings_${panelId}`).setLabel('⭐ Avaliações').setStyle(ButtonStyle.Primary)
    );
}

function autoCloseRow(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`back_to_genconfig_${panelId}`).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId(`autoclose_leave_${panelId}`).setLabel('🚪 Sair').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId(`autoclose_inactive_${panelId}`).setLabel('⏱️ Inatividade').setStyle(ButtonStyle.Primary)
    );
}

function ticketTypeSelectRow(panelId, currentType) {
    return new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId(`select_ticket_type_${panelId}`).setPlaceholder('📍 Selecione o tipo...').addOptions([
            { label: '📝 Canal', value: 'channel', description: 'Cria um canal separado', default: (currentType || 'channel') === 'channel' },
            { label: '💬 Tópico', value: 'thread', description: 'Cria um tópico', default: currentType === 'thread' }
        ])
    );
}

// ==================== SELEÇÃO ====================

function panelSelectRow(panels, customId) {
    const options = panels.slice(0, 25).map(p => ({
        label: String(p.name || p.title || 'Sem nome').substring(0, 100),
        value: p.id,
        emoji: p.button_emoji || '🎫',
        description: `${p.is_active ? '✅' : '❌'} | ${p.ticket_type === 'thread' ? 'Tópico' : 'Canal'}`
    }));
    return new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId(customId || 'select_panel_edit').setPlaceholder('🔍 Selecione...').addOptions(options.length > 0 ? options : [{ label: 'Nenhum', value: 'none', emoji: '❌' }])
    );
}

function deleteConfirmRow(panelId) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('back_to_main').setLabel('⬅️ Cancelar').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId(`delete_confirm_${panelId}`).setLabel('🗑️ Confirmar').setStyle(ButtonStyle.Danger)
    );
}

function channelSelectRow(guild, customId) {
    const channels = guild.channels.cache.filter(c => c.type === 0).first(25);
    const options = [];
    for (const c of channels) {
        const label = '#' + c.name;
        if (label.length > 100) continue;
        options.push({
            label: label.substring(0, 100),
            value: c.id,
            emoji: '📝',
            description: (c.parent ? c.parent.name : 'Sem categoria').substring(0, 100)
        });
    }
    if (options.length === 0) {
        options.push({ label: 'Nenhum canal', value: 'none', emoji: '❌', description: 'Nenhum disponível' });
    }
    return new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId(customId || 'select_channel').setPlaceholder('📡 Selecione um canal...').addOptions(options)
    );
}

function categorySelectRow(guild, customId) {
    const categories = guild.channels.cache.filter(c => c.type === 4).first(25);
    const options = categories.map(c => ({ label: c.name.substring(0, 100), value: c.id, emoji: '📂' }));
    return new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId(customId || 'select_category').setPlaceholder('📂 Selecione uma categoria...').addOptions(options.length > 0 ? options : [{ label: 'Nenhuma', value: 'none', emoji: '❌' }])
    );
}

function roleSelectRow(guild, customId) {
    const roles = guild.roles.cache.filter(r => r.name !== '@everyone' && !r.managed).first(25);
    const options = roles.map(r => ({ label: r.name.substring(0, 100), value: r.id, emoji: '👥' }));
    return new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder().setCustomId(customId || 'select_role').setPlaceholder('👥 Selecione um cargo...').addOptions(options.length > 0 ? options : [{ label: 'Nenhum', value: 'none', emoji: '❌' }])
    );
}

// ==================== TICKETS ====================

function ticketButtons(ticketId) {
    const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ticket_claim_' + ticketId).setLabel('🙋 Assumir').setStyle(ButtonStyle.Success),
        new ButtonBuilder().setCustomId('ticket_add_' + ticketId).setLabel('➕ Adicionar').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('ticket_remove_' + ticketId).setLabel('➖ Remover').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('ticket_transfer_' + ticketId).setLabel('🔗 Transferir').setStyle(ButtonStyle.Secondary)
    );
    const row2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('ticket_close_' + ticketId).setLabel('🔒 Fechar').setStyle(ButtonStyle.Danger),
        new ButtonBuilder().setCustomId('ticket_call_' + ticketId).setLabel('📞 Call').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('ticket_rating_' + ticketId).setLabel('⭐ Avaliar').setStyle(ButtonStyle.Secondary)
    );
    return [row1, row2];
}

function ticketDropdown(panelId, options) {
    const opts = options.slice(0, 25).map(o => ({
        label: String(o.name).substring(0, 100),
        value: 'open_' + panelId + '_' + o.id,
        emoji: String(o.emoji || '💬').substring(0, 10),
        description: String(o.description || '').substring(0, 100)
    }));
    return new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
            .setCustomId('ticket_select_' + panelId)
            .setPlaceholder('🔽 Selecione o motivo do atendimento...')
            .addOptions(opts.length > 0 ? opts : [{ label: 'Nenhuma opção', value: 'none', emoji: '❌' }])
    );
}

// ==================== AVALIAÇÃO ====================

function ratingModal(ticketId) {
    return new ModalBuilder()
        .setCustomId('modal_rating_' + ticketId)
        .setTitle('⭐ Avaliar Atendimento')
        .addComponents(
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('rating_score').setLabel('Nota (1 a 5)').setPlaceholder('Digite de 1 a 5').setStyle(TextInputStyle.Short).setRequired(true).setMaxLength(1)),
            new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('rating_feedback').setLabel('Comentário (opcional)').setPlaceholder('Deixe seu feedback...').setStyle(TextInputStyle.Paragraph).setRequired(false).setMaxLength(500))
        );
}

// ==================== OPÇÃO CONFIG ====================

function optionConfigEmbed(opt) {
    return new EmbedBuilder()
        .setColor('#00FFFF')
        .setTitle('⚙️ Configurar: ' + (opt[3] || 'Opção'))
        .addFields(
            { name: '👥 Cargo', value: opt[6] ? `<@&${opt[6]}>` : 'Padrão', inline: true },
            { name: '📂 Categoria', value: opt[5] ? `<#${opt[5]}>` : 'Padrão', inline: true },
            { name: '💬 Boas-vindas', value: opt[7] || 'Padrão', inline: false },
            { name: '🔒 Fechamento', value: opt[8] || 'Padrão', inline: false },
            { name: '🖼️ Imagem', value: opt[12] ? '✅' : '❌', inline: true },
            { name: '🏷️ Thumbnail', value: opt[13] ? '✅' : '❌', inline: true }
        )
        .setFooter({ text: 'NH RP • Configuração' })
        .setTimestamp();
}

function optionConfigRows(optionId, pid) {
    const row1 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('optconfig_role_' + optionId).setLabel('👥 Cargo').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('optconfig_category_' + optionId).setLabel('📂 Categoria').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('optconfig_image_' + optionId).setLabel('🖼️ Imagens').setStyle(ButtonStyle.Primary)
    );
    const row2 = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('optconfig_welcome_' + optionId).setLabel('💬 Boas-vindas').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('optconfig_close_' + optionId).setLabel('🔒 Fechamento').setStyle(ButtonStyle.Primary),
        new ButtonBuilder().setCustomId('optconfig_desc_' + optionId).setLabel('📝 Descrição').setStyle(ButtonStyle.Primary)
    );
    const backBtn = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId('back_to_options_' + pid).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary)
    );
    return [row1, row2, backBtn];
}

// ==================== EXPORTAÇÕES ====================

module.exports = {
    mainMenuRow,
    mainMenuRow2,
    backToMainRow,
    quickSetupConfirmRow,
    customSetupRow,
    customSetupRow2,
    customSetupRow3,
    titleModal,
    descriptionModal,
    colorModal,
    authorModal,
    imageModal,
    footerModal,
    panelNameModal,
    autoCloseInactiveModal,
    selectMessageModal,
    colorSelectRow,
    colorButtonRow,
    optionsSelectRow,
    optionsMainRow,
    optionsRow2,
    optionsRow3,
    optionsRow4,
    optionCreateModal,
    optionOrderRow,
    optionRemoveConfirmRow,
    generalConfigRow,
    generalConfigRow2,
    generalConfigRow3,
    generalConfigRow4,
    autoCloseRow,
    ticketTypeSelectRow,
    panelSelectRow,
    deleteConfirmRow,
    channelSelectRow,
    categorySelectRow,
    roleSelectRow,
    ticketButtons,
    ticketDropdown,
    ratingModal,
    optionConfigEmbed,
    optionConfigRows
};
