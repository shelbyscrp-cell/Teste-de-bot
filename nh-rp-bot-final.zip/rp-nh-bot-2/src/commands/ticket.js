const { SlashCommandBuilder } = require('discord.js');
const { mainMenuEmbed } = require('../utils/embeds');
const { mainMenuRow, mainMenuRow2 } = require('../interfaces/components');

module.exports = {
    data: new SlashCommandBuilder()
        .setName('ticket')
        .setDescription('🎫 Abre o painel de gerenciamento de tickets'),
    async execute(interaction) {
        await interaction.reply({
            embeds: [mainMenuEmbed(interaction.guild.name, interaction.guild.iconURL())],
            components: [mainMenuRow(), mainMenuRow2()],
            flags: [64]
        });
    }
};
