require('dotenv').config();
const { Client, GatewayIntentBits, Partials, Collection, REST, Routes } = require('discord.js');
const path = require('path');
const fs = require('fs-extra');
const logger = require('./utils/logger');
const { initializeDatabase } = require('./database/schema');

const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.GuildModeration,
        GatewayIntentBits.GuildInvites,
        GatewayIntentBits.GuildWebhooks
    ],
    partials: [Partials.Channel, Partials.Message, Partials.User, Partials.GuildMember]
});

client.commands = new Collection();

async function loadCommands() {
    const commandsPath = path.join(__dirname, 'commands');
    if (!fs.existsSync(commandsPath)) return [];
    const commandFiles = fs.readdirSync(commandsPath).filter(file => file.endsWith('.js'));
    const commandsData = [];
    for (const file of commandFiles) {
        const command = require(path.join(commandsPath, file));
        if ('data' in command && 'execute' in command) {
            client.commands.set(command.data.name, command);
            commandsData.push(command.data.toJSON());
            logger.info(`✅ Comando: /${command.data.name}`);
        }
    }
    return commandsData;
}

async function loadEvents() {
    const eventsPath = path.join(__dirname, 'events');
    if (!fs.existsSync(eventsPath)) return;
    const eventFiles = fs.readdirSync(eventsPath).filter(file => file.endsWith('.js'));
    for (const file of eventFiles) {
        const event = require(path.join(eventsPath, file));
        if (event.once) {
            client.once(event.name, (...args) => event.execute(...args, client));
        } else {
            client.on(event.name, (...args) => event.execute(...args, client));
        }
        logger.info(`✅ Evento: ${event.name}`);
    }
}

async function registerCommands(commandsData) {
    const rest = new REST({ version: '10' }).setToken(process.env.TOKEN);
    try {
        logger.info('📝 Registrando comandos...');
        await rest.put(
            Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID),
            { body: commandsData }
        );
        logger.info(`✅ ${commandsData.length} comandos registrados!`);
    } catch (error) {
        logger.error('Erro ao registrar comandos:', error);
    }
}

(async () => {
    try {
        console.log('\n🎨 NH RP BOT 2');
        console.log('🟢 Iniciando...\n');
        await initializeDatabase();
        const commandsData = await loadCommands();
        await loadEvents();
        await registerCommands(commandsData);
        await client.login(process.env.TOKEN);
        console.log('\n✅ NH RP BOT ONLINE!\n');
    } catch (error) {
        console.error('❌ ERRO:', error.message);
        process.exit(1);
    }
})();

process.on('unhandledRejection', (error) => logger.error('Erro:', error));
module.exports = client;
