const { ActivityType } = require('discord.js');
const logger = require('../utils/logger');

module.exports = {
    name: 'ready',
    once: true,
    async execute(client) {
        logger.info(`🤖 ${client.user.tag} online`);

        const statuses = [
            { name: 'NH RP • Tickets', type: ActivityType.Watching },
            { name: '🛡️ Protegendo', type: ActivityType.Playing }
        ];

        let i = 0;
        setInterval(() => {
            client.user.setPresence({ activities: [statuses[i]], status: 'online' });
            i = (i + 1) % statuses.length;
        }, 15000);

        console.log('✅ NH RP BOT ONLINE!');
    }
};
