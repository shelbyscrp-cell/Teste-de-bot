const { Events, ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, EmbedBuilder, ChannelType, AttachmentBuilder, ModalBuilder, TextInputBuilder, TextInputStyle } = require('discord.js');
const logger = require('../utils/logger');
const { getDatabase, saveDatabase } = require('../database/connection');
const { v4: uuidv4 } = require('uuid');
const {
    THEME, successReply, errorReply, warningReply, infoReply, permissionDenied,
    mainMenuEmbed, panelPreviewEmbed, ticketClaimedEmbed, ticketClosedEmbed,
    ticketTransferredEmbed, ticketCreatedEmbed, ticketLogEmbed, statsEmbed, ratingEmbed
} = require('../utils/embeds');
const {
    mainMenuRow, mainMenuRow2, backToMainRow, quickSetupConfirmRow,
    customSetupRow, customSetupRow2, customSetupRow3,
    titleModal, descriptionModal, colorModal, authorModal, imageModal, footerModal,
    colorSelectRow, colorButtonRow,
    optionsSelectRow, optionsMainRow, optionsRow2, optionsRow3, optionsRow4,
    optionCreateModal, optionOrderRow, optionRemoveConfirmRow, selectMessageModal,
    generalConfigRow, generalConfigRow2, generalConfigRow3, generalConfigRow4,
    autoCloseRow, autoCloseInactiveModal, panelNameModal,
    ticketTypeSelectRow, panelSelectRow, deleteConfirmRow, channelSelectRow,
    categorySelectRow, roleSelectRow,
    ticketButtons, ticketDropdown, ratingModal, optionConfigEmbed, optionConfigRows
} = require('../interfaces/components');

const DEFAULT_DESC = '**Seja Bem-vindo ao suporte de nossa Cidade!**\n\n> *Para garantir um atendimento rápido e eficiente, leia atentamente as informações abaixo.*\n\n━━━━━━━━━━━━━━━━━━━━━━\n\n📋 **Regras do Atendimento**\n\n```1.``` Aguarde um Staff te atender. **Não os marque** sem necessidade real.\n\n```2.``` Enquanto aguarda, explique com **clareza e objetividade** o motivo da abertura do ticket.\n\n```3.``` Seja **respeitoso** com os Trabalhadores da Cidade. Eles estão aqui para te ajudar!\n\n━━━━━━━━━━━━━━━━━━━━━━\n\n⚠️ **Aviso Importante**\nTickets com objetivo de "troll" resultam em **punição severa** ou até **banimento**. Só abra um ticket se realmente houver um motivo válido.\n\n━━━━━━━━━━━━━━━━━━━━━━\n\n🕒 **Aguarde com paciência.** Um Staff irá te atender em breve!';
const DEFAULT_IMG = 'https://cdn.discordapp.com/attachments/1350922977243304063/1525250927932604487/ChatGPT_Image_9_de_jul._de_2026_18_39_32.png';

module.exports = {
    name: Events.InteractionCreate,
    async execute(interaction, client) {
        try {
            if (interaction.isChatInputCommand()) {
                const cmd = client.commands.get(interaction.commandName);
                if (!cmd) return;
                if (!interaction.member.roles.cache.has(process.env.ADMIN_ROLE_ID)) {
                    return interaction.reply({ embeds: [permissionDenied()], flags: [64] });
                }
                await cmd.execute(interaction, client);
                return;
            }
            if (interaction.isButton()) { await handleButton(interaction, client); return; }
            if (interaction.isStringSelectMenu()) { await handleSelectMenu(interaction, client); return; }
            if (interaction.isModalSubmit()) { await handleModal(interaction, client); return; }
        } catch (e) {
            logger.error('Erro:', e);
            try {
                if (interaction.replied || interaction.deferred) await interaction.followUp({ embeds: [errorReply('Erro interno.')], flags: [64] }).catch(() => {});
                else await interaction.reply({ embeds: [errorReply('Erro interno.')], flags: [64] }).catch(() => {});
            } catch (e2) {}
        }
    }
};

async function handleButton(interaction, client) {
    const { customId } = interaction;
    const db = await getDatabase();

    try {
        // ==================== MENU PRINCIPAL ====================
        if (customId === 'back_to_main') {
            const g = interaction.guild;
            await interaction.update({ embeds: [mainMenuEmbed(g.name, g.iconURL())], components: [mainMenuRow(), mainMenuRow2()] });
            return;
        }

        if (customId === 'stats_menu') {
            const today = new Date().toISOString().split('T')[0];
            const to = db.exec("SELECT COUNT(*) FROM active_tickets WHERE guild_id=? AND date(created_at)=?", [interaction.guildId, today]);
            const tc = db.exec("SELECT COUNT(*) FROM active_tickets WHERE guild_id=? AND date(closed_at)=?", [interaction.guildId, today]);
            const tto = db.exec("SELECT COUNT(*) FROM active_tickets WHERE guild_id=? AND status='open'", [interaction.guildId]);
            const ttc = db.exec("SELECT COUNT(*) FROM active_tickets WHERE guild_id=? AND status='closed'", [interaction.guildId]);
            let avg = 'N/A';
            try {
                const r = db.exec("SELECT AVG(rating) FROM active_tickets WHERE guild_id=? AND rating IS NOT NULL", [interaction.guildId]);
                if (r.length > 0 && r[0].values.length > 0 && r[0].values[0][0] !== null) avg = Number(r[0].values[0][0]).toFixed(1);
            } catch (e) {}
            const toVal = to[0]?.values[0]?.[0] || 0;
            const tcVal = tc[0]?.values[0]?.[0] || 0;
            const ttoVal = tto[0]?.values[0]?.[0] || 0;
            const ttcVal = ttc[0]?.values[0]?.[0] || 0;
            await interaction.update({ embeds: [statsEmbed(toVal, tcVal, ttoVal, ttcVal, avg, null)], components: [backToMainRow()] });
            return;
        }

        // ==================== CONFIGURAÇÃO RÁPIDA ====================
        if (customId === 'quick_setup') {
            const embed = new EmbedBuilder().setColor(THEME.primary).setTitle('⚡ Configuração Rápida').setDescription('O bot criará automaticamente toda a estrutura!').addFields({ name: '📋 Será criado:', value: '• 5 Cargos de Equipe\n• Categoria Tickets\n• Canal abrir-ticket\n• Canal logs-tickets\n• Canal avaliacoes\n• Painel com 5 opções' }).setFooter({ text: 'NH RP' }).setTimestamp();
            await interaction.update({ embeds: [embed], components: [quickSetupConfirmRow()] });
            return;
        }

        if (customId === 'quick_setup_confirm') {
            await interaction.deferUpdate();
            await handleQuickSetup(interaction, client);
            return;
        }

        // ==================== CRIAR PAINEL ====================
        if (customId === 'custom_setup') {
            const pid = uuidv4();
            const thumb = client.user.displayAvatarURL({ dynamic: true });
            db.run('INSERT INTO ticket_panels (id, guild_id, title, description, color, author_name, author_icon, footer_text, image_url, thumbnail_url, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 0)',
                [pid, interaction.guildId, '© SUPORTE NH-BOT', DEFAULT_DESC, '#00FFFF', '©Colt Programmer', thumb, 'Novo Horizonte Roleplay - Todos os Direitos Reservados©', DEFAULT_IMG, thumb]);
            saveDatabase();
            const p = getPanelById(db, pid);
            const embed = panelPreviewEmbed(p);
            await interaction.update({ embeds: [embed], components: [customSetupRow(pid), customSetupRow2(pid), customSetupRow3(pid)] });
            return;
        }

        // ==================== VOLTAR AO PAINEL ====================
        if (customId.startsWith('back_to_panel_')) {
            const pid = customId.replace('back_to_panel_', '');
            const p = getPanelById(db, pid);
            if (!p) { await interaction.update({ embeds: [errorReply('Painel não encontrado.')], components: [backToMainRow()] }); return; }
            await interaction.update({ embeds: [panelPreviewEmbed(p)], components: [customSetupRow(pid), customSetupRow2(pid), customSetupRow3(pid)] });
            return;
        }

// ==================== EDITAR PAINEL ====================
if (customId.startsWith('panel_title_')) { const pid = customId.replace('panel_title_', ''); const p = getPanelById(db, pid); await interaction.showModal(titleModal(pid, p?.title || '', p?.author_url || '')); return; }
if (customId.startsWith('panel_desc_')) { const pid = customId.replace('panel_desc_', ''); const p = getPanelById(db, pid); await interaction.showModal(descriptionModal(pid, p?.description || '')); return; }
if (customId.startsWith('panel_color_modal_')) { const pid = customId.replace('panel_color_modal_', ''); await interaction.showModal(colorModal(pid)); return; }
if (customId.startsWith('panel_color_')) { const pid = customId.replace('panel_color_', ''); await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('🎨 Cor').setDescription('Escolha no dropdown ou informe a cor.').setFooter({ text: 'NH RP' }).setTimestamp()], components: [colorSelectRow(pid), colorButtonRow(pid)] }); return; }
if (customId.startsWith('panel_author_')) { const pid = customId.replace('panel_author_', ''); const p = getPanelById(db, pid); await interaction.showModal(authorModal(pid, p?.author_name || '', p?.author_url || '', p?.author_icon || '')); return; }
if (customId.startsWith('panel_image_')) { const pid = customId.replace('panel_image_', ''); const p = getPanelById(db, pid); await interaction.showModal(imageModal(pid, p?.image_url || '', p?.thumbnail_url || '')); return; }
if (customId.startsWith('panel_footer_')) { const pid = customId.replace('panel_footer_', ''); const p = getPanelById(db, pid); await interaction.showModal(footerModal(pid, p?.footer_text || '', p?.footer_icon || '')); return; }

// ==================== OPÇÕES ====================
if (customId.startsWith('panel_options_')) { const pid = customId.replace('panel_options_', ''); await showOptionsMenu(interaction, db, pid); return; }
if (customId.startsWith('option_create_')) { const pid = customId.replace('option_create_', ''); await interaction.showModal(optionCreateModal(pid)); return; }
if (customId.startsWith('option_msg_')) { const pid = customId.replace('option_msg_', ''); await interaction.showModal(selectMessageModal(pid)); return; }
if (customId.startsWith('back_to_options_')) { const pid = customId.replace('back_to_options_', ''); await showOptionsMenu(interaction, db, pid); return; }

if (customId.startsWith('option_edit_')) {
    const pid = customId.replace('option_edit_', '');
    const opts = db.exec('SELECT * FROM ticket_options WHERE panel_id = ? ORDER BY sort_order', [pid]);
    if (opts.length === 0 || opts[0].values.length === 0) { await interaction.reply({ embeds: [warningReply('Nenhuma opção.')], flags: [64] }); return; }
    const list = opts[0].values.map(o => ({ id: o[0], emoji: o[2], name: o[3], description: o[4] }));
    const sel = new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('select_opt_edit_' + pid).setPlaceholder('Selecione...').addOptions(list.map(o => ({ label: o.name, value: o.id, emoji: o.emoji }))));
    const backBtn = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('back_to_options_' + pid).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary));
    await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('✏️ Editar Opção').setDescription('Selecione:').setFooter({ text: 'NH RP' }).setTimestamp()], components: [sel, backBtn] });
    return;
}

if (customId.startsWith('option_order_')) {
    const pid = customId.replace('option_order_', '');
    const opts = db.exec('SELECT * FROM ticket_options WHERE panel_id = ? ORDER BY sort_order', [pid]);
    if (opts.length === 0 || opts[0].values.length === 0) { await interaction.reply({ embeds: [warningReply('Nenhuma opção.')], flags: [64] }); return; }
    const list = opts[0].values.map(o => ({ id: o[0], emoji: o[2], name: o[3], description: o[4] }));
    await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('🔄 Ordem').setDescription('Use as setas.').setFooter({ text: 'NH RP' }).setTimestamp()], components: [optionsSelectRow(pid, list), optionOrderRow(pid)] });
    return;
}

if (customId.startsWith('option_move_up_')) {
    const pid = customId.replace('option_move_up_', '');
    const opts = db.exec('SELECT * FROM ticket_options WHERE panel_id = ? ORDER BY sort_order', [pid]);
    if (opts.length > 0 && opts[0].values.length > 1) {
        const list = opts[0].values;
        const last = list[list.length - 1];
        const prev = list[list.length - 2];
        db.run('UPDATE ticket_options SET sort_order = ? WHERE id = ?', [last[5], prev[0]]);
        db.run('UPDATE ticket_options SET sort_order = ? WHERE id = ?', [prev[5], last[0]]);
        saveDatabase();
    }
    await interaction.reply({ embeds: [successReply('⬆️ Movido!')], flags: [64] });
    return;
}

if (customId.startsWith('option_move_down_')) {
    const pid = customId.replace('option_move_down_', '');
    const opts = db.exec('SELECT * FROM ticket_options WHERE panel_id = ? ORDER BY sort_order', [pid]);
    if (opts.length > 0 && opts[0].values.length > 1) {
        const list = opts[0].values;
        const first = list[0];
        const second = list[1];
        db.run('UPDATE ticket_options SET sort_order = ? WHERE id = ?', [first[5], second[0]]);
        db.run('UPDATE ticket_options SET sort_order = ? WHERE id = ?', [second[5], first[0]]);
        saveDatabase();
    }
    await interaction.reply({ embeds: [successReply('⬇️ Movido!')], flags: [64] });
    return;
}

if (customId.startsWith('option_config_')) {
    const pid = customId.replace('option_config_', '');
    const opts = db.exec('SELECT * FROM ticket_options WHERE panel_id = ? ORDER BY sort_order', [pid]);
    if (opts.length === 0 || opts[0].values.length === 0) { await interaction.reply({ embeds: [warningReply('Nenhuma opção.')], flags: [64] }); return; }
    const list = opts[0].values.map(o => ({ id: o[0], emoji: o[2], name: o[3] }));
    const sel = new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('select_opt_config_' + pid).setPlaceholder('Selecione...').addOptions(list.map(o => ({ label: o.name, value: o.id, emoji: o.emoji }))));
    const backBtn = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('back_to_options_' + pid).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary));
    await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('⚙️ Configurar').setDescription('Selecione:').setFooter({ text: 'NH RP' }).setTimestamp()], components: [sel, backBtn] });
    return;
}

if (customId.startsWith('option_remove_')) {
    const pid = customId.replace('option_remove_', '');
    const opts = db.exec('SELECT * FROM ticket_options WHERE panel_id = ? ORDER BY sort_order', [pid]);
    if (opts.length === 0 || opts[0].values.length === 0) { await interaction.reply({ embeds: [warningReply('Nenhuma opção.')], flags: [64] }); return; }
    const list = opts[0].values.map(o => ({ id: o[0], emoji: o[2], name: o[3], description: o[4] }));
    await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.danger).setTitle('🗑️ Remover').setDescription('Selecione e confirme:').setFooter({ text: 'NH RP' }).setTimestamp()], components: [optionsSelectRow(pid, list), optionRemoveConfirmRow(pid)] });
    return;
}

if (customId.startsWith('option_remove_confirm_')) {
    const pid = customId.replace('option_remove_confirm_', '');
    const opts = db.exec('SELECT * FROM ticket_options WHERE panel_id = ? ORDER BY sort_order DESC', [pid]);
    if (opts.length > 0 && opts[0].values.length > 0) {
        const o = opts[0].values[0];
        db.run('DELETE FROM ticket_options WHERE id = ?', [o[0]]);
        saveDatabase();
        await interaction.reply({ embeds: [successReply('✅ ' + o[3] + ' removida!')], flags: [64] });
    }
    return;
}

// ==================== CONFIG GERAIS ====================
if (customId.startsWith('panel_genconfig_')) { const pid = customId.replace('panel_genconfig_', ''); await showGenConfig(interaction, db, pid); return; }
if (customId.startsWith('genconfig_name_')) { const pid = customId.replace('genconfig_name_', ''); const p = getPanelById(db, pid); await interaction.showModal(panelNameModal(pid, p?.name || '')); return; }
if (customId.startsWith('genconfig_userclose_')) { const pid = customId.replace('genconfig_userclose_', ''); const p = getPanelById(db, pid); const nv = p?.allow_user_close ? 0 : 1; db.run('UPDATE ticket_panels SET allow_user_close = ? WHERE id = ?', [nv, pid]); saveDatabase(); await interaction.reply({ embeds: [successReply('Dono fechar: ' + (nv ? '✅ Ativado' : '❌ Desativado'))], flags: [64] }); return; }
if (customId.startsWith('genconfig_autoclose_')) { const pid = customId.replace('genconfig_autoclose_', ''); await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('♻️ Auto Close').setDescription('Configure o fechamento automático.').setFooter({ text: 'NH RP' }).setTimestamp()], components: [autoCloseRow(pid)] }); return; }
if (customId.startsWith('autoclose_leave_')) { const pid = customId.replace('autoclose_leave_', ''); const p = getPanelById(db, pid); const nv = p?.auto_close_member_leave ? 0 : 1; db.run('UPDATE ticket_panels SET auto_close_member_leave = ? WHERE id = ?', [nv, pid]); saveDatabase(); await interaction.reply({ embeds: [successReply('Sair: ' + (nv ? '✅' : '❌'))], flags: [64] }); return; }
if (customId.startsWith('autoclose_inactive_')) { const pid = customId.replace('autoclose_inactive_', ''); const p = getPanelById(db, pid); await interaction.showModal(autoCloseInactiveModal(pid, p?.auto_close_inactivity || '')); return; }
if (customId.startsWith('genconfig_limit_')) { const pid = customId.replace('genconfig_limit_', ''); const p = getPanelById(db, pid); const nv = p?.limit_one_ticket ? 0 : 1; db.run('UPDATE ticket_panels SET limit_one_ticket = ? WHERE id = ?', [nv, pid]); saveDatabase(); await interaction.reply({ embeds: [successReply('Limitar: ' + (nv ? '✅' : '❌'))], flags: [64] }); return; }
if (customId.startsWith('back_to_genconfig_')) { const pid = customId.replace('back_to_genconfig_', ''); await showGenConfig(interaction, db, pid); return; }

if (customId.startsWith('genconfig_type_')) {
    const pid = customId.replace('genconfig_type_', '');
    const p = getPanelById(db, pid);
    const backBtn = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('back_to_genconfig_' + pid).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary));
    await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('📍 Tipo').setDescription('Canal ou Tópico?').setFooter({ text: 'NH RP' }).setTimestamp()], components: [ticketTypeSelectRow(pid, p?.ticket_type || 'channel'), backBtn] });
    return;
}

if (customId.startsWith('genconfig_category_')) {
    const pid = customId.replace('genconfig_category_', '');
    const backBtn = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('back_to_genconfig_' + pid).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary));
    await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('📂 Categoria').setDescription('Selecione:').setFooter({ text: 'NH RP' }).setTimestamp()], components: [categorySelectRow(interaction.guild, 'select_category_' + pid), backBtn] });
    return;
}

if (customId.startsWith('genconfig_logs_')) {
    const pid = customId.replace('genconfig_logs_', '');
    const backBtn = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('back_to_genconfig_' + pid).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary));
    await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('📄 Logs').setDescription('Selecione:').setFooter({ text: 'NH RP' }).setTimestamp()], components: [channelSelectRow(interaction.guild, 'select_logs_' + pid), backBtn] });
    return;
}

if (customId.startsWith('genconfig_topic_')) {
    const pid = customId.replace('genconfig_topic_', '');
    const p = getPanelById(db, pid);
    if (p?.ticket_type !== 'thread') { await interaction.reply({ embeds: [warningReply('Selecione Tópico primeiro.')], flags: [64] }); return; }
    const backBtn = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('back_to_genconfig_' + pid).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary));
    await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('💬 Tópico').setDescription('Selecione:').setFooter({ text: 'NH RP' }).setTimestamp()], components: [channelSelectRow(interaction.guild, 'select_topic_' + pid), backBtn] });
    return;
}

if (customId.startsWith('genconfig_extraroles_')) {
    const pid = customId.replace('genconfig_extraroles_', '');
    const p = getPanelById(db, pid);
    const backBtn = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('back_to_genconfig_' + pid).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary));
    const embed = new EmbedBuilder().setColor(THEME.primary).setTitle('👥 Cargos Extra').setDescription('Selecione os cargos extras que atenderão tickets.\n\n**Atuais:** ' + (p?.extra_roles ? p.extra_roles.split(',').map(r => '<@&' + r.trim() + '>').join(', ') : 'Nenhum')).setFooter({ text: 'NH RP' }).setTimestamp();
    await interaction.update({ embeds: [embed], components: [roleSelectRow(interaction.guild, 'select_extrarole_' + pid), backBtn] });
    return;
}

if (customId.startsWith('genconfig_ratings_')) {
    const pid = customId.replace('genconfig_ratings_', '');
    const backBtn = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('back_to_genconfig_' + pid).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary));
    await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('⭐ Avaliações').setDescription('Selecione o canal de avaliações:').setFooter({ text: 'NH RP' }).setTimestamp()], components: [channelSelectRow(interaction.guild, 'select_ratings_' + pid), backBtn] });
    return;
}

        // ==================== SALVAR / ENVIAR / EDITAR / EXCLUIR ====================
        if (customId.startsWith('panel_save_')) {
            const pid = customId.replace('panel_save_', '');
            const p = getPanelById(db, pid);
            if (!p?.ticket_type) return interaction.reply({ embeds: [warningReply('⚠️ Defina Canal ou Tópico!')], flags: [64] });
            if (!p?.name) return interaction.reply({ embeds: [warningReply('⚠️ Nomeie o painel!')], flags: [64] });
            if (!p?.transcript_channel_id) return interaction.reply({ embeds: [warningReply('⚠️ Defina o canal de logs!')], flags: [64] });
            const opts = db.exec('SELECT COUNT(*) FROM ticket_options WHERE panel_id = ?', [pid]);
            if ((opts[0]?.values[0]?.[0] || 0) === 0) return interaction.reply({ embeds: [warningReply('⚠️ Crie pelo menos 1 opção!')], flags: [64] });
            db.run('UPDATE ticket_panels SET is_active = 1 WHERE id = ?', [pid]);
            saveDatabase();
            await interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.success).setTitle('💾 Salvo!').setDescription(`**${p.title}** salvo!`).addFields({ name: '📝 Nome', value: p.name, inline: true }, { name: '📍 Tipo', value: p.ticket_type === 'thread' ? 'Tópico' : 'Canal', inline: true }, { name: '➕ Opções', value: `${opts[0]?.values[0]?.[0] || 0}`, inline: true }).setFooter({ text: 'NH RP' }).setTimestamp()], flags: [64] });
            return;
        }

        if (customId.startsWith('panel_send_')) {
            const pid = customId.replace('panel_send_', '');
            const p = getPanelById(db, pid);
            if (!p?.is_active) return interaction.reply({ embeds: [warningReply('⚠️ Salve o painel antes de enviar!')], flags: [64] });
            await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('📤 Enviar').setDescription('Selecione o canal:').setFooter({ text: 'NH RP' }).setTimestamp()], components: [channelSelectRow(interaction.guild, 'send_panel_' + pid), backToMainRow()] });
            return;
        }

        if (customId === 'edit_panel_menu') {
            const panels = db.exec('SELECT * FROM ticket_panels WHERE guild_id = ? AND is_active = 1', [interaction.guildId]);
            if (panels.length === 0 || panels[0].values.length === 0) { await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.info).setTitle('📋 Nenhum').setDescription('Nenhum painel salvo.').setFooter({ text: 'NH RP' }).setTimestamp()], components: [backToMainRow()] }); return; }
            const list = panels[0].values.map(r => getPanelById(db, r[0]));
            await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('✏️ Editar').setDescription(`${list.length} painel(is).`).setFooter({ text: 'NH RP' }).setTimestamp()], components: [panelSelectRow(list, 'select_panel_edit'), backToMainRow()] });
            return;
        }

        if (customId === 'delete_panel_menu') {
            const panels = db.exec('SELECT * FROM ticket_panels WHERE guild_id = ? AND is_active = 1', [interaction.guildId]);
            if (panels.length === 0 || panels[0].values.length === 0) { await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.info).setTitle('📋 Nenhum').setDescription('Nenhum painel.').setFooter({ text: 'NH RP' }).setTimestamp()], components: [backToMainRow()] }); return; }
            const list = panels[0].values.map(r => getPanelById(db, r[0]));
            await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.danger).setTitle('🗑️ Excluir').setDescription(`${list.length} painel(is).`).setFooter({ text: 'NH RP' }).setTimestamp()], components: [panelSelectRow(list, 'select_panel_delete'), backToMainRow()] });
            return;
        }

        if (customId.startsWith('delete_confirm_')) {
            const pid = customId.replace('delete_confirm_', '');
            db.run('DELETE FROM ticket_options WHERE panel_id = ?', [pid]);
            db.run('DELETE FROM ticket_panels WHERE id = ?', [pid]);
            saveDatabase();
            await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.success).setTitle('✅ Excluído!').setFooter({ text: 'NH RP' }).setTimestamp()], components: [backToMainRow()] });
            return;
        }

        // ==================== TICKETS ====================
        if (customId.startsWith('ticket_open_')) { const pts = customId.replace('ticket_open_', '').split('_'); await handleTicketOpen(interaction, db, pts[0], pts.slice(1).join('_')); return; }

        if (customId.startsWith('ticket_claim_')) {
            const tid = customId.replace('ticket_claim_', '');
            const t = db.exec('SELECT * FROM active_tickets WHERE id = ?', [tid]);
            if (t.length > 0 && t[0].values.length > 0) {
                const row = t[0].values[0];
                if (row[6]) { await interaction.reply({ embeds: [warningReply(`Já assumido por <@${row[6]}>.`)], flags: [64] }); return; }
                db.run('UPDATE active_tickets SET claimed_by = ?, status = ?, first_response_at = COALESCE(first_response_at, datetime(\'now\')) WHERE id = ?', [interaction.user.id, 'claimed', tid]);
                saveDatabase();
                await interaction.reply({ embeds: [ticketClaimedEmbed(interaction.user, row[5], tid)] });
                const panel = getPanelById(db, row[2]);
                if (panel?.transcript_channel_id) { const lc = interaction.guild.channels.cache.get(panel.transcript_channel_id); if (lc) await lc.send({ embeds: [ticketClaimedEmbed(interaction.user, row[5], tid).setTitle('📝 Ticket Assumido')] }); }
            }
            return;
        }

        if (customId.startsWith('ticket_close_')) {
            await interaction.deferReply();
            const tid = customId.replace('ticket_close_', '');
            const t = db.exec('SELECT * FROM active_tickets WHERE id = ?', [tid]);
            if (t.length > 0 && t[0].values.length > 0) {
                const row = t[0].values[0];
                const userId = row[5], panelId = row[2];
                const channel = interaction.channel;
                db.run("UPDATE active_tickets SET status = ?, closed_at = datetime('now') WHERE id = ?", ['closed', tid]);
                saveDatabase();

                let transcript = `📄 TRANSCRIPT - NH RP\n━━━━━━━━━━━━━━━━━━\n🎫 ID: #${tid.substring(0, 8)}\n👤 Cliente: <@${userId}>\n👮 Fechado por: ${interaction.user.tag}\n📅 Data: ${new Date().toLocaleString('pt-BR')}\n━━━━━━━━━━━━━━━━━━\n\n`;
                let msgCount = 0;
                try { const messages = await channel.messages.fetch({ limit: 100 }); const sorted = Array.from(messages.values()).reverse(); msgCount = sorted.length; for (const m of sorted) { transcript += `[${new Date(m.createdTimestamp).toLocaleTimeString('pt-BR')}] ${m.author.tag}: ${m.content || '(📎 mídia)'}\n`; } } catch (e) {}

                const pdfBuffer = Buffer.from(transcript, 'utf-8');
                const attachment = new AttachmentBuilder(pdfBuffer, { name: `transcript-${tid.substring(0, 8)}.txt` });
                await interaction.editReply({ embeds: [ticketClosedEmbed(interaction.user, userId, msgCount)], files: [attachment] });

                try { const user = await interaction.client.users.fetch(userId); await user.send({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('🔒 Ticket Fechado').setDescription(`Seu ticket foi fechado por **${interaction.user.tag}**.\n\n⭐ **Avalie o atendimento!**`).setTimestamp()], files: [attachment], components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('dm_rating_' + tid).setLabel('⭐ Avaliar').setStyle(ButtonStyle.Primary))] }); } catch (e) {}

                const panel = getPanelById(db, panelId);
                if (panel?.transcript_channel_id) { const lc = interaction.guild.channels.cache.get(panel.transcript_channel_id); if (lc) { await lc.send({ embeds: [new EmbedBuilder().setColor(THEME.danger).setTitle('📄 Transcript').addFields({ name: '🎫', value: '#' + tid.substring(0, 8) }, { name: '👤', value: `<@${userId}>` }, { name: '👮', value: interaction.user.toString() }).setTimestamp()], files: [attachment] }); } }

                const calls = interaction.guild.channels.cache.filter(c => c.type === ChannelType.GuildVoice && c.name.includes('atendimento-'));
                for (const [, vc] of calls) { try { await vc.delete(); } catch (e) {} }
                setTimeout(() => channel.delete().catch(() => {}), 5000);
            }
            return;
        }

        if (customId.startsWith('ticket_add_')) {
            const tid = customId.replace('ticket_add_', '');
            await interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.primary).setDescription('👤 Mencione o usuário para adicionar:').setFooter({ text: 'NH RP' }).setTimestamp()], flags: [64] });
            const col = interaction.channel.createMessageCollector({ filter: m => m.author.id === interaction.user.id && m.mentions.users.size > 0, max: 1, time: 30000 });
            col.on('collect', async (m) => { const u = m.mentions.users.first(); if (u) { await interaction.channel.permissionOverwrites.create(u.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true }); db.run('INSERT OR IGNORE INTO ticket_members (ticket_id, user_id, added_by) VALUES (?, ?, ?)', [tid, u.id, interaction.user.id]); saveDatabase(); await m.reply({ embeds: [successReply(`✅ ${u} adicionado!`)] }); } });
            return;
        }

        if (customId.startsWith('ticket_remove_')) {
            const tid = customId.replace('ticket_remove_', '');
            await interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.danger).setDescription('👤 Mencione o usuário para remover:').setFooter({ text: 'NH RP' }).setTimestamp()], flags: [64] });
            const col = interaction.channel.createMessageCollector({ filter: m => m.author.id === interaction.user.id && m.mentions.users.size > 0, max: 1, time: 30000 });
            col.on('collect', async (m) => { const u = m.mentions.users.first(); if (u) { await interaction.channel.permissionOverwrites.delete(u.id).catch(() => {}); db.run('DELETE FROM ticket_members WHERE ticket_id = ? AND user_id = ?', [tid, u.id]); saveDatabase(); await m.reply({ embeds: [successReply(`✅ ${u} removido!`)] }); } });
            return;
        }

        if (customId.startsWith('ticket_transfer_')) {
            const tid = customId.replace('ticket_transfer_', '');
            await interaction.reply({ embeds: [new EmbedBuilder().setColor(THEME.warning).setDescription('👤 Mencione o staff:').setFooter({ text: 'NH RP' }).setTimestamp()], flags: [64] });
            const col = interaction.channel.createMessageCollector({ filter: m => m.author.id === interaction.user.id && m.mentions.users.size > 0, max: 1, time: 30000 });
            col.on('collect', async (m) => { const u = m.mentions.users.first(); if (u) { db.run('UPDATE active_tickets SET claimed_by = ? WHERE id = ?', [u.id, tid]); saveDatabase(); await m.reply({ embeds: [ticketTransferredEmbed(interaction.user, u)] }); } });
            return;
        }

        if (customId.startsWith('ticket_call_')) {
            const tid = customId.replace('ticket_call_', '');
            const t = db.exec('SELECT channel_id, user_id FROM active_tickets WHERE id = ?', [tid]);
            if (t.length > 0 && t[0].values.length > 0) {
                const ch = interaction.guild.channels.cache.get(t[0].values[0][0]);
                const uid = t[0].values[0][1];
                if (ch) {
                    try {
                        const userName = (await interaction.client.users.fetch(uid).catch(() => ({}))).username || 'usuario';
                        const vc = await interaction.guild.channels.create({ name: '🔊 atendimento-' + userName.toLowerCase().replace(/[^a-z0-9]/g, ''), type: ChannelType.GuildVoice, parent: ch.parentId, permissionOverwrites: [{ id: interaction.guild.roles.everyone, deny: ['ViewChannel', 'Connect'] }, { id: interaction.user.id, allow: ['ViewChannel', 'Connect', 'Speak'] }, { id: uid, allow: ['ViewChannel', 'Connect', 'Speak'] }] });
                        await ch.send({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('📞 Call').setDescription(`Clique: ${vc}`).setTimestamp()] });
                        await interaction.reply({ embeds: [successReply('📞 Call criada!')] });
                    } catch (e) { await interaction.reply({ embeds: [errorReply('Erro ao criar call.')], flags: [64] }); }
                }
            }
            return;
        }

        if (customId.startsWith('dm_rating_')) { const tid = customId.replace('dm_rating_', ''); await interaction.showModal(ratingModal(tid)); return; }
        if (customId.startsWith('ticket_rating_')) { await interaction.reply({ embeds: [warningReply('A avaliação será enviada na DM após fechar.')], flags: [64] }); return; }

        // ==================== CONFIGURAÇÃO DE OPÇÕES ====================
        if (customId.startsWith('optconfig_role_')) { const optionId = customId.replace('optconfig_role_', ''); const o = db.exec('SELECT panel_id FROM ticket_options WHERE id = ?', [optionId]); if (o.length > 0) { const pid = o[0].values[0][0]; const backBtn = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('back_to_optconfig_' + optionId).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary)); await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('👥 Cargo').setDescription('Selecione:').setFooter({ text: 'NH RP' }).setTimestamp()], components: [roleSelectRow(interaction.guild, 'set_optrole_' + optionId), backBtn] }); } return; }
        if (customId.startsWith('optconfig_category_')) { const optionId = customId.replace('optconfig_category_', ''); const o = db.exec('SELECT panel_id FROM ticket_options WHERE id = ?', [optionId]); if (o.length > 0) { const pid = o[0].values[0][0]; const backBtn = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('back_to_optconfig_' + optionId).setLabel('↩️ Voltar').setStyle(ButtonStyle.Secondary)); await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.primary).setTitle('📂 Categoria').setDescription('Selecione:').setFooter({ text: 'NH RP' }).setTimestamp()], components: [categorySelectRow(interaction.guild, 'set_optcat_' + optionId), backBtn] }); } return; }
        if (customId.startsWith('optconfig_welcome_')) { const optionId = customId.replace('optconfig_welcome_', ''); const o = db.exec('SELECT welcome_message FROM ticket_options WHERE id = ?', [optionId]); const msg = o.length > 0 && o[0].values.length > 0 ? o[0].values[0][0] || '' : ''; await interaction.showModal(new ModalBuilder().setCustomId('modal_opt_welcome_' + optionId).setTitle('💬 Boas-vindas').addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('msg').setLabel('Mensagem').setPlaceholder('Bem-vindo!').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(2000).setValue(msg)))); return; }
        if (customId.startsWith('optconfig_close_')) { const optionId = customId.replace('optconfig_close_', ''); const o = db.exec('SELECT close_message FROM ticket_options WHERE id = ?', [optionId]); const msg = o.length > 0 && o[0].values.length > 0 ? o[0].values[0][0] || '' : ''; await interaction.showModal(new ModalBuilder().setCustomId('modal_opt_close_' + optionId).setTitle('🔒 Fechamento').addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('msg').setLabel('Mensagem').setPlaceholder('Ticket fechado.').setStyle(TextInputStyle.Paragraph).setRequired(true).setMaxLength(2000).setValue(msg)))); return; }
        if (customId.startsWith('optconfig_image_')) { const optionId = customId.replace('optconfig_image_', ''); const o = db.exec('SELECT image_url, thumbnail_url FROM ticket_options WHERE id = ?', [optionId]); const img = o.length > 0 && o[0].values.length > 0 ? o[0].values[0][0] || '' : ''; const thumb = o.length > 0 && o[0].values.length > 0 ? o[0].values[0][1] || '' : ''; await interaction.showModal(new ModalBuilder().setCustomId('modal_opt_image_' + optionId).setTitle('🖼️ Imagens').addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('img').setLabel('Imagem (URL)').setPlaceholder('https://...').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(500).setValue(img)), new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('thumb').setLabel('Thumbnail (URL)').setPlaceholder('https://...').setStyle(TextInputStyle.Short).setRequired(false).setMaxLength(500).setValue(thumb)))); return; }
        if (customId.startsWith('optconfig_desc_')) { const optionId = customId.replace('optconfig_desc_', ''); const o = db.exec('SELECT description FROM ticket_options WHERE id = ?', [optionId]); const desc = o.length > 0 && o[0].values.length > 0 ? o[0].values[0][0] || '' : ''; await interaction.showModal(new ModalBuilder().setCustomId('modal_opt_desc_' + optionId).setTitle('📝 Descrição').addComponents(new ActionRowBuilder().addComponents(new TextInputBuilder().setCustomId('desc').setLabel('Descrição').setPlaceholder('Descreva...').setStyle(TextInputStyle.Paragraph).setRequired(false).setMaxLength(1000).setValue(desc)))); return; }
        if (customId.startsWith('back_to_optconfig_')) { const optionId = customId.replace('back_to_optconfig_', ''); await showOptionConfigById(interaction, db, optionId); return; }

        await interaction.reply({ content: 'Comando não reconhecido.', flags: [64] }).catch(() => {});

    } catch (e) {
        logger.error('Erro handleButton:', e);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ embeds: [errorReply('Erro interno.')], flags: [64] }).catch(() => {});
        }
    }
}

async function handleSelectMenu(interaction, client) {
    const { customId, values } = interaction;
    const db = await getDatabase();

    if (interaction.replied || interaction.deferred) return;

    try {
        if (customId.startsWith('select_option_')) { await interaction.deferUpdate().catch(() => {}); return; }

        if (customId.startsWith('select_color_')) {
            const pid = customId.replace('select_color_', '');
            db.run('UPDATE ticket_panels SET color = ? WHERE id = ?', [values[0], pid]);
            saveDatabase();
            const p = getPanelById(db, pid);
            if (!p) { await interaction.update({ embeds: [errorReply('Painel não encontrado.')], components: [backToMainRow()] }); return; }
            await interaction.update({ embeds: [panelPreviewEmbed(p)], components: [customSetupRow(pid), customSetupRow2(pid), customSetupRow3(pid)] });
            return;
        }

        if (customId.startsWith('select_panel_edit')) { const pid = values[0]; if (pid === 'none') return; const p = getPanelById(db, pid); if (!p) { await interaction.update({ embeds: [errorReply('Painel não encontrado.')], components: [backToMainRow()] }); return; } await interaction.update({ embeds: [panelPreviewEmbed(p)], components: [customSetupRow(pid), customSetupRow2(pid), customSetupRow3(pid)] }); return; }
        if (customId.startsWith('select_panel_delete')) { const pid = values[0]; if (pid === 'none') return; const p = getPanelById(db, pid); if (!p) { await interaction.update({ embeds: [errorReply('Painel não encontrado.')], components: [backToMainRow()] }); return; } await interaction.update({ embeds: [new EmbedBuilder().setColor(THEME.danger).setTitle('⚠️ Confirmar').setDescription(`Excluir **${p.title}**?`).setFooter({ text: 'NH RP' }).setTimestamp()], components: [deleteConfirmRow(pid)] }); return; }
        if (customId.startsWith('select_ticket_type_')) { const pid = customId.replace('select_ticket_type_', ''); db.run('UPDATE ticket_panels SET ticket_type = ? WHERE id = ?', [values[0], pid]); saveDatabase(); await interaction.reply({ embeds: [successReply(`Tipo: **${values[0] === 'thread' ? 'Tópico' : 'Canal'}**`)], flags: [64] }); return; }
        if (customId.startsWith('select_category_')) { const pid = customId.replace('select_category_', ''); db.run('UPDATE ticket_panels SET category_id = ? WHERE id = ?', [values[0], pid]); saveDatabase(); await interaction.reply({ embeds: [successReply('✅ Categoria definida!')], flags: [64] }); return; }
        if (customId.startsWith('select_logs_')) { const pid = customId.replace('select_logs_', ''); if (values[0] === 'none') return; db.run('UPDATE ticket_panels SET transcript_channel_id = ? WHERE id = ?', [values[0], pid]); saveDatabase(); await interaction.reply({ embeds: [successReply('✅ Canal de logs definido!')], flags: [64] }); return; }
        if (customId.startsWith('select_topic_')) { const pid = customId.replace('select_topic_', ''); db.run('UPDATE ticket_panels SET topic_channel_id = ? WHERE id = ?', [values[0], pid]); saveDatabase(); await interaction.reply({ embeds: [successReply(`Tópico: <#${values[0]}>`)], flags: [64] }); return; }
        if (customId.startsWith('select_ratings_')) { const pid = customId.replace('select_ratings_', ''); db.run('UPDATE ticket_panels SET rating_channel_id = ? WHERE id = ?', [values[0], pid]); saveDatabase(); await interaction.reply({ embeds: [successReply(`Avaliações: <#${values[0]}>`)], flags: [64] }); return; }

        if (customId.startsWith('send_panel_')) {
            const pid = customId.replace('send_panel_', '');
            const channelId = values[0];
            if (channelId === 'none') { await interaction.reply({ embeds: [errorReply('Canal inválido.')], flags: [64] }); return; }
            const channel = interaction.guild.channels.cache.get(channelId);
            if (!channel || channel.type !== ChannelType.GuildText) { await interaction.reply({ embeds: [errorReply('Canal de texto inválido.')], flags: [64] }); return; }
            const p = getPanelById(db, pid);
            if (!p) { await interaction.reply({ embeds: [errorReply('Painel não encontrado.')], flags: [64] }); return; }
            const embed = panelPreviewEmbed(p);
            const opts = db.exec('SELECT * FROM ticket_options WHERE panel_id = ? ORDER BY sort_order', [pid]);
            if (opts.length > 0 && opts[0].values.length > 0) {
                const dropdownOptions = [];
                for (const o of opts[0].values) {
                    dropdownOptions.push({ label: String(o[3] || 'Opção').substring(0, 100), value: 'open_' + pid + '_' + o[0], emoji: String(o[2] || '💬').substring(0, 10), description: String(o[4] || '').substring(0, 100) });
                }
                if (dropdownOptions.length > 0) {
                    const dropdown = new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('ticket_select_' + pid).setPlaceholder('🔽 Selecione o motivo...').addOptions(dropdownOptions));
                    await channel.send({ embeds: [embed], components: [dropdown] });
                } else { await channel.send({ embeds: [embed] }); }
            } else {
                const btn = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('ticket_open_' + pid + '_default').setLabel('🎫 Abrir Ticket').setStyle(ButtonStyle.Primary));
                await channel.send({ embeds: [embed], components: [btn] });
            }
            await interaction.reply({ embeds: [successReply(`✅ Painel enviado em ${channel}!`)], flags: [64] });
            return;
        }

        if (customId.startsWith('ticket_select_')) { const value = values[0]; if (value === 'none') return; const parts = value.replace('open_', '').split('_'); const panelId = parts[0]; const optionId = parts.slice(1).join('_'); await handleTicketOpen(interaction, db, panelId, optionId); return; }
        if (customId.startsWith('select_opt_edit_')) { const pid = customId.replace('select_opt_edit_', ''); const o = db.exec('SELECT * FROM ticket_options WHERE id = ?', [values[0]]); if (o.length > 0 && o[0].values.length > 0) { const r = o[0].values[0]; await interaction.showModal(optionCreateModal(pid, values[0], r[2], r[3], r[4])); } return; }
        if (customId.startsWith('select_opt_config_')) { const optionId = values[0]; await showOptionConfigById(interaction, db, optionId); return; }
        if (customId.startsWith('select_extrarole_')) { const pid = customId.replace('select_extrarole_', ''); const p = getPanelById(db, pid); const currentRoles = p?.extra_roles ? p.extra_roles.split(',').filter(r => r.trim()) : []; if (currentRoles.includes(values[0])) { await interaction.reply({ embeds: [warningReply('Cargo já adicionado!')], flags: [64] }); return; } currentRoles.push(values[0]); db.run('UPDATE ticket_panels SET extra_roles = ? WHERE id = ?', [currentRoles.join(','), pid]); saveDatabase(); await interaction.reply({ embeds: [successReply('✅ Cargo adicionado!')], flags: [64] }); return; }
        if (customId.startsWith('set_optrole_')) { const optionId = customId.replace('set_optrole_', ''); db.run('UPDATE ticket_options SET support_role_id = ? WHERE id = ?', [values[0], optionId]); saveDatabase(); await interaction.reply({ embeds: [successReply('✅ Cargo definido!')], flags: [64] }); return; }
        if (customId.startsWith('set_optcat_')) { const optionId = customId.replace('set_optcat_', ''); db.run('UPDATE ticket_options SET category_id = ? WHERE id = ?', [values[0], optionId]); saveDatabase(); await interaction.reply({ embeds: [successReply('✅ Categoria definida!')], flags: [64] }); return; }

    } catch (e) {
        logger.error('Erro handleSelectMenu:', e);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ embeds: [errorReply('Erro na seleção.')], flags: [64] }).catch(() => {});
        }
    }
}

async function handleModal(interaction, client) {
    const { customId } = interaction;
    const db = await getDatabase();
    const f = (n) => interaction.fields.getTextInputValue(n);

    if (interaction.replied || interaction.deferred) return;

    try {
        if (customId.startsWith('modal_title_')) { const pid = customId.replace('modal_title_', ''); db.run('UPDATE ticket_panels SET title = ?, author_url = ? WHERE id = ?', [f('title'), f('title_url'), pid]); saveDatabase(); await showPanelUpdated(interaction, db, pid); return; }
        if (customId.startsWith('modal_desc_')) { const pid = customId.replace('modal_desc_', ''); db.run('UPDATE ticket_panels SET description = ? WHERE id = ?', [f('description'), pid]); saveDatabase(); await showPanelUpdated(interaction, db, pid); return; }
        if (customId.startsWith('modal_color_')) { const pid = customId.replace('modal_color_', ''); const color = f('color'); if (!/^#[0-9A-Fa-f]{6}$/.test(color)) { await interaction.reply({ embeds: [errorReply('Cor inválida! Use #00FFFF')], flags: [64] }); return; } db.run('UPDATE ticket_panels SET color = ? WHERE id = ?', [color, pid]); saveDatabase(); await showPanelUpdated(interaction, db, pid); return; }
        if (customId.startsWith('modal_author_')) { const pid = customId.replace('modal_author_', ''); db.run('UPDATE ticket_panels SET author_name = ?, author_url = ?, author_icon = ? WHERE id = ?', [f('author_name'), f('author_url'), f('author_icon'), pid]); saveDatabase(); await showPanelUpdated(interaction, db, pid); return; }
        if (customId.startsWith('modal_image_')) { const pid = customId.replace('modal_image_', ''); db.run('UPDATE ticket_panels SET image_url = ?, thumbnail_url = ? WHERE id = ?', [f('image_url'), f('thumbnail_url'), pid]); saveDatabase(); await showPanelUpdated(interaction, db, pid); return; }
        if (customId.startsWith('modal_footer_')) { const pid = customId.replace('modal_footer_', ''); db.run('UPDATE ticket_panels SET footer_text = ?, footer_icon = ? WHERE id = ?', [f('footer_text'), f('footer_icon'), pid]); saveDatabase(); await showPanelUpdated(interaction, db, pid); return; }
        if (customId.startsWith('modal_create_option_')) { const pid = customId.replace('modal_create_option_', ''); const oid = uuidv4(); const max = db.exec('SELECT MAX(sort_order) FROM ticket_options WHERE panel_id = ?', [pid]); const next = (max[0]?.values[0]?.[0] || 0) + 1; db.run('INSERT INTO ticket_options (id, panel_id, emoji, name, description, sort_order) VALUES (?, ?, ?, ?, ?, ?)', [oid, pid, f('option_emoji'), f('option_name'), f('option_desc'), next]); saveDatabase(); await interaction.reply({ embeds: [successReply(`✅ Opção **${f('option_name')}** criada!`)], flags: [64] }); return; }
        if (customId.startsWith('modal_edit_option_')) { const pts = customId.replace('modal_edit_option_', '').split('_'); const pid = pts[0]; const oid = pts.slice(1).join('_'); db.run('UPDATE ticket_options SET name = ?, emoji = ?, description = ? WHERE id = ?', [f('option_name'), f('option_emoji'), f('option_desc'), oid]); saveDatabase(); await interaction.reply({ embeds: [successReply(`✅ Opção **${f('option_name')}** atualizada!`)], flags: [64] }); return; }
        if (customId.startsWith('modal_select_msg_')) { await interaction.reply({ embeds: [successReply('✅ Mensagem atualizada!')], flags: [64] }); return; }
        if (customId.startsWith('modal_panel_name_')) { const pid = customId.replace('modal_panel_name_', ''); db.run('UPDATE ticket_panels SET name = ? WHERE id = ?', [f('panel_name'), pid]); saveDatabase(); await interaction.reply({ embeds: [successReply(`✅ Nome **${f('panel_name')}** salvo!`)], flags: [64] }); return; }
        if (customId.startsWith('modal_autoclose_inactive_')) { const pid = customId.replace('modal_autoclose_inactive_', ''); const time = f('inactive_time'); db.run('UPDATE ticket_panels SET auto_close_inactivity = ? WHERE id = ?', [time, pid]); saveDatabase(); await interaction.reply({ embeds: [successReply(time ? `✅ Auto close: **${time}**` : '✅ Desativado!')], flags: [64] }); return; }

        if (customId.startsWith('modal_rating_')) {
            const tid = customId.replace('modal_rating_', '');
            const rating = parseInt(f('rating_score'));
            const feedback = f('rating_feedback');
            if (isNaN(rating) || rating < 1 || rating > 5) { await interaction.reply({ embeds: [errorReply('Nota inválida! Digite de 1 a 5.')], flags: [64] }); return; }
            db.run('UPDATE active_tickets SET rating = ?, rating_feedback = ? WHERE id = ?', [rating, feedback, tid]);
            saveDatabase();
            const ticket = db.exec('SELECT user_id, panel_id FROM active_tickets WHERE id = ?', [tid]);
            if (ticket.length > 0 && ticket[0].values.length > 0) {
                const userId = ticket[0].values[0][0];
                const panelId = ticket[0].values[0][1];
                const user = await interaction.client.users.fetch(userId).catch(() => null);
                await interaction.reply({ embeds: [ratingEmbed(user || interaction.user, rating, feedback)] });
                const panel = getPanelById(db, panelId);
                if (panel?.rating_channel_id) { const lc = interaction.guild.channels.cache.get(panel.rating_channel_id); if (lc) await lc.send({ embeds: [ratingEmbed(user || interaction.user, rating, feedback).setTitle('⭐ Nova Avaliação')] }); }
            }
            return;
        }

        if (customId.startsWith('modal_opt_welcome_')) { const optionId = customId.replace('modal_opt_welcome_', ''); db.run('UPDATE ticket_options SET welcome_message = ? WHERE id = ?', [f('msg'), optionId]); saveDatabase(); await interaction.reply({ embeds: [successReply('✅ Boas-vindas salva!')], flags: [64] }); return; }
        if (customId.startsWith('modal_opt_close_')) { const optionId = customId.replace('modal_opt_close_', ''); db.run('UPDATE ticket_options SET close_message = ? WHERE id = ?', [f('msg'), optionId]); saveDatabase(); await interaction.reply({ embeds: [successReply('✅ Fechamento salvo!')], flags: [64] }); return; }
        if (customId.startsWith('modal_opt_image_')) { const optionId = customId.replace('modal_opt_image_', ''); db.run('UPDATE ticket_options SET image_url = ?, thumbnail_url = ? WHERE id = ?', [f('img'), f('thumb'), optionId]); saveDatabase(); await interaction.reply({ embeds: [successReply('✅ Imagens atualizadas!')], flags: [64] }); return; }
        if (customId.startsWith('modal_opt_desc_')) { const optionId = customId.replace('modal_opt_desc_', ''); db.run('UPDATE ticket_options SET description = ? WHERE id = ?', [f('desc'), optionId]); saveDatabase(); await interaction.reply({ embeds: [successReply('✅ Descrição atualizada!')], flags: [64] }); return; }

    } catch (e) {
        logger.error('Erro handleModal:', e);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({ embeds: [errorReply('Erro ao salvar.')], flags: [64] }).catch(() => {});
        }
    }
}

// ==================== FUNÇÕES AUXILIARES ====================

function getPanelById(db, id) {
    const r = db.exec('SELECT * FROM ticket_panels WHERE id = ?', [id]);
    if (r.length === 0 || r[0].values.length === 0) return null;
    const row = r[0].values[0];
    const panel = {
        id: row[0], guild_id: row[1], name: row[2], channel_id: row[3],
        title: row[4], description: row[5], color: row[6],
        author_name: row[7], author_url: row[8], author_icon: row[9],
        footer_text: row[10], footer_icon: row[11], thumbnail_url: row[12],
        image_url: row[13], button_emoji: row[14], button_label: row[15],
        category_id: row[16], support_role_id: row[17], extra_roles: row[18],
        ticket_name_format: row[19], ticket_limit: row[20],
        welcome_message: row[21], close_message: row[22],
        transcript_channel_id: row[23], is_active: row[24],
        ticket_type: row[25], topic_channel_id: row[26],
        allow_user_close: row[27], auto_close_member_leave: row[28],
        auto_close_inactivity: row[29], limit_one_ticket: row[30],
        rating_channel_id: row[31] || null
    };
    const opts = db.exec('SELECT * FROM ticket_options WHERE panel_id = ? ORDER BY sort_order', [id]);
    if (opts.length > 0 && opts[0].values.length > 0) {
        panel.options = opts[0].values.map(o => ({ id: o[0], emoji: o[2], name: o[3], description: o[4] }));
    } else {
        panel.options = [];
    }
    return panel;
}

async function showPanelUpdated(interaction, db, pid) {
    const p = getPanelById(db, pid);
    if (!p) return;
    await interaction.update({ embeds: [panelPreviewEmbed(p)], components: [customSetupRow(pid), customSetupRow2(pid), customSetupRow3(pid)] });
}

async function showGenConfig(interaction, db, pid) {
    const p = getPanelById(db, pid);
    const embed = new EmbedBuilder()
        .setColor(THEME.primary)
        .setTitle('⚙️ Configurações Gerais')
        .addFields(
            { name: '📍 Tipo', value: (p?.ticket_type === 'thread' ? '```Tópico```' : '```Canal```'), inline: true },
            { name: '📝 Nome', value: p?.name ? '```' + p.name + '```' : '```Não definido```', inline: true },
            { name: '📂 Categoria', value: p?.category_id ? '<#' + p.category_id + '>' : '```Não definida```', inline: true },
            { name: '📄 Logs', value: p?.transcript_channel_id ? '<#' + p.transcript_channel_id + '>' : '```Não definido```', inline: true },
            { name: '💬 Tópico', value: p?.topic_channel_id ? '<#' + p.topic_channel_id + '>' : '```Não definido```', inline: true },
            { name: '⭐ Avaliações', value: p?.rating_channel_id ? '<#' + p.rating_channel_id + '>' : '```Não definido```', inline: true },
            { name: '🔒 Dono fechar', value: p?.allow_user_close ? '```Ativado```' : '```Desativado```', inline: true },
            { name: '🚪 Sair', value: p?.auto_close_member_leave ? '```Ativado```' : '```Desativado```', inline: true },
            { name: '⏱️ Inatividade', value: p?.auto_close_inactivity ? '```' + p.auto_close_inactivity + '```' : '```Desativado```', inline: true },
            { name: '🔢 Limitar', value: p?.limit_one_ticket ? '```1 ticket```' : '```Ilimitado```', inline: true },
            { name: '👥 Cargos Extra', value: p?.extra_roles ? p.extra_roles.split(',').map(r => '<@&' + r.trim() + '>').join(', ') : '```Nenhum```', inline: false }
        )
        .setFooter({ text: 'NH RP • Configurações' })
        .setTimestamp();
    await interaction.update({ embeds: [embed], components: [generalConfigRow(pid), generalConfigRow2(pid), generalConfigRow3(pid), generalConfigRow4(pid)] });
}

async function showOptionsMenu(interaction, db, pid) {
    const opts = db.exec('SELECT * FROM ticket_options WHERE panel_id = ? ORDER BY sort_order', [pid]);
    const list = opts.length > 0 ? opts[0].values.map(o => ({ id: o[0], emoji: o[2], name: o[3], description: o[4] })) : [];
    const embed = new EmbedBuilder().setColor(THEME.primary).setTitle('➕ Gerenciar Opções').setDescription(`**${list.length}** opção(ões).`).setFooter({ text: 'NH RP' }).setTimestamp();
    const components = [optionsMainRow(pid), optionsRow2(pid), optionsRow3(pid), optionsRow4(pid)];
    if (list.length > 0) components.unshift(optionsSelectRow(pid, list));
    await interaction.update({ embeds: [embed], components });
}

async function showOptionConfigById(interaction, db, optionId) {
    const o = db.exec('SELECT * FROM ticket_options WHERE id = ?', [optionId]);
    if (o.length > 0 && o[0].values.length > 0) {
        const opt = o[0].values[0];
        const pid = opt[1];
        const embed = optionConfigEmbed(opt);
        const components = optionConfigRows(optionId, pid);
        await interaction.update({ embeds: [embed], components });
    }
}

async function handleTicketOpen(interaction, db, panelId, optionId) {
    const panel = getPanelById(db, panelId);
    if (!panel) return interaction.reply({ embeds: [errorReply('Painel não encontrado.')], flags: [64] });
    const guild = interaction.guild;
    const member = interaction.member;

    if (panel.limit_one_ticket) {
        const r = db.exec('SELECT COUNT(*) FROM active_tickets WHERE guild_id = ? AND user_id = ? AND status = ?', [guild.id, member.id, 'open']);
        if ((r[0]?.values[0]?.[0] || 0) >= 1) return interaction.reply({ embeds: [warningReply('Você já possui um ticket aberto!')], flags: [64] });
    }

    const opt = db.exec('SELECT * FROM ticket_options WHERE id = ?', [optionId]);
    const optName = opt.length > 0 && opt[0].values.length > 0 ? opt[0].values[0][3] : 'Ticket';
    const optRole = opt.length > 0 && opt[0].values.length > 0 ? opt[0].values[0][6] : null;
    const effectiveRole = optRole || panel.support_role_id;

    let chName = (panel.ticket_name_format || '{username}').replace('{username}', member.user.username).toLowerCase().replace(/[^a-z0-9-]/g, '').substring(0, 50);
    if (!chName || chName.trim() === '') chName = 'ticket';
    const cat = guild.channels.cache.get(panel.category_id) || guild.channels.cache.find(c => c.name === '🎫 TICKETS' && c.type === 4);

    try {
        if (panel.ticket_type === 'thread' && panel.topic_channel_id) {
            const topicChannel = guild.channels.cache.get(panel.topic_channel_id);
            if (topicChannel && topicChannel.type === ChannelType.GuildText) {
                const thread = await topicChannel.threads.create({ name: chName, type: ChannelType.PrivateThread });
                await thread.members.add(member.id);
                if (effectiveRole) { const role = guild.roles.cache.get(effectiveRole); if (role) { const members = await guild.members.fetch(); members.filter(m => m.roles.cache.has(role.id)).forEach(async sm => { await thread.members.add(sm.id).catch(() => {}); }); } }
                const tid = uuidv4();
                db.run('INSERT INTO active_tickets (id, guild_id, panel_id, option_id, channel_id, user_id, status) VALUES (?, ?, ?, ?, ?, ?, ?)', [tid, guild.id, panelId, optionId, thread.id, member.id, 'open']);
                saveDatabase();
                await thread.send({ content: `${member}`, embeds: [ticketCreatedEmbed(panel, member, optName, tid)], components: ticketButtons(tid) });
                await interaction.reply({ embeds: [successReply('✅ Ticket criado! ' + thread.toString())], flags: [64] });
                if (panel.transcript_channel_id) { const lc = guild.channels.cache.get(panel.transcript_channel_id); if (lc) await lc.send({ embeds: [ticketLogEmbed(member, optName, tid, thread)] }); }
                return;
            }
        }

        const tc = await guild.channels.create({
            name: chName, type: ChannelType.GuildText, parent: cat?.id || null,
            permissionOverwrites: [
                { id: guild.roles.everyone.id, deny: ['ViewChannel'] },
                { id: member.id, allow: ['ViewChannel', 'SendMessages', 'ReadMessageHistory', 'AttachFiles'] }
            ]
        });

        if (effectiveRole) { const role = guild.roles.cache.get(effectiveRole); if (role) await tc.permissionOverwrites.create(role.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true, AttachFiles: true, ManageMessages: true }).catch(() => {}); }
        if (panel.extra_roles) { for (const rid of panel.extra_roles.split(',')) { const r = guild.roles.cache.get(rid.trim()); if (r) await tc.permissionOverwrites.create(r.id, { ViewChannel: true, SendMessages: true, ReadMessageHistory: true }).catch(() => {}); } }

        const tid = uuidv4();
        db.run('INSERT INTO active_tickets (id, guild_id, panel_id, option_id, channel_id, user_id, status) VALUES (?, ?, ?, ?, ?, ?, ?)', [tid, guild.id, panelId, optionId, tc.id, member.id, 'open']);
        saveDatabase();
        await tc.send({ content: `${member}`, embeds: [ticketCreatedEmbed(panel, member, optName, tid)], components: ticketButtons(tid) });
        await interaction.reply({ embeds: [successReply('✅ Ticket criado! ' + tc.toString())], flags: [64] });
        if (panel.transcript_channel_id) { const lc = guild.channels.cache.get(panel.transcript_channel_id); if (lc) await lc.send({ embeds: [ticketLogEmbed(member, optName, tid, tc)] }); }
    } catch (e) {
        logger.error('Erro ao criar ticket:', e);
        let msg = 'Erro ao criar ticket.';
        if (e.code) msg += ' Código: ' + e.code;
        if (e.message) msg += '\n' + e.message.substring(0, 200);
        return interaction.reply({ embeds: [errorReply(msg)], flags: [64] });
    }
}

async function handleQuickSetup(interaction, client) {
    const guild = interaction.guild;
    const db = await getDatabase();

    const roleNames = ['💬', '🚨', '💰', '🤝', '❓'];
    const roleNamesFull = ['Suporte', 'Denúncias', 'Pagamentos', 'Parcerias', 'Atendimentos Gerais'];
    const roles = {};

    for (let i = 0; i < roleNames.length; i++) {
        let role = guild.roles.cache.find(r => r.name === `𝄡 ${roleNames[i]} — Equipe . de . ${roleNamesFull[i]}`);
        if (!role) role = await guild.roles.create({ name: `𝄡 ${roleNames[i]} — Equipe . de . ${roleNamesFull[i]}`, color: '#00FFFF' });
        roles[roleNamesFull[i]] = role;
    }

    let cat = guild.channels.cache.find(c => c.name === '┣┅ ◦ 🎟️ | Tickets' && c.type === 4);
    if (!cat) cat = await guild.channels.create({ name: '┣┅ ◦ 🎟️ | Tickets', type: ChannelType.GuildCategory });

    let central = guild.channels.cache.find(c => c.name === '「🎟️」abrir-ticket');
    if (!central) central = await guild.channels.create({ name: '「🎟️」abrir-ticket', type: ChannelType.GuildText, parent: cat.id, permissionOverwrites: [{ id: guild.roles.everyone, allow: ['ViewChannel', 'ReadMessageHistory'] }, ...Object.values(roles).map(r => ({ id: r.id, allow: ['ViewChannel', 'ReadMessageHistory', 'SendMessages', 'EmbedLinks'] }))] });

    let logs = guild.channels.cache.find(c => c.name === '「📝」logs-tickets');
    if (!logs) logs = await guild.channels.create({ name: '「📝」logs-tickets', type: ChannelType.GuildText, parent: cat.id, permissionOverwrites: [{ id: guild.roles.everyone, deny: ['ViewChannel'] }, ...Object.values(roles).map(r => ({ id: r.id, allow: ['ViewChannel', 'ReadMessageHistory', 'SendMessages'] }))] });

    let ratings = guild.channels.cache.find(c => c.name === '「⭐」avaliacoes');
    if (!ratings) ratings = await guild.channels.create({ name: '「⭐」avaliacoes', type: ChannelType.GuildText, parent: cat.id, permissionOverwrites: [{ id: guild.roles.everyone, deny: ['ViewChannel'] }, ...Object.values(roles).map(r => ({ id: r.id, allow: ['ViewChannel', 'ReadMessageHistory', 'SendMessages'] }))] });

    const pid = uuidv4();
    const thumb = client.user.displayAvatarURL({ dynamic: true });
    db.run('INSERT INTO ticket_panels (id, guild_id, title, description, color, author_name, author_icon, footer_text, image_url, thumbnail_url, transcript_channel_id, rating_channel_id, category_id, name, ticket_type, welcome_message, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1)',
        [pid, guild.id, '© SUPORTE NH-BOT', DEFAULT_DESC, '#00FFFF', '©Colt Programmer', thumb, 'Novo Horizonte Roleplay - Todos os Direitos Reservados©', DEFAULT_IMG, thumb, logs.id, ratings.id, cat.id, 'Painel Rápido', 'channel', 'Olá! Bem-vindo ao seu ticket.\n\nDescreva seu problema abaixo e um staff irá atendê-lo.']);

    const defs = [
        { e: '💬', n: 'Suporte', d: 'Dúvidas, erros ou ajuda', role: roles['Suporte'] },
        { e: '🚨', n: 'Denúncias', d: 'Reporte de usuários', role: roles['Denúncias'] },
        { e: '💰', n: 'Pagamentos', d: 'Problemas com compras', role: roles['Pagamentos'] },
        { e: '🤝', n: 'Parcerias', d: 'Propostas de colaboração', role: roles['Parcerias'] },
        { e: '❓', n: 'Atendimentos Gerais', d: 'Outros atendimentos', role: roles['Atendimentos Gerais'] }
    ];
    defs.forEach((o, i) => db.run('INSERT INTO ticket_options (id, panel_id, emoji, name, description, sort_order, support_role_id) VALUES (?, ?, ?, ?, ?, ?, ?)', [uuidv4(), pid, o.e, o.n, o.d, i + 1, o.role.id]));
    saveDatabase();

    const panel = getPanelById(db, pid);
    const embed = panelPreviewEmbed(panel);
    const opts = db.exec('SELECT * FROM ticket_options WHERE panel_id = ? ORDER BY sort_order', [pid]);
    const dd = opts[0].values.map(o => ({ label: String(o[3]), value: 'open_' + pid + '_' + o[0], emoji: String(o[2]), description: String(o[4]).substring(0, 100) }));
    await central.send({ embeds: [embed], components: [new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('ticket_select_' + pid).setPlaceholder('🔽 Selecione o motivo...').addOptions(dd))] });

    await interaction.editReply({ embeds: [new EmbedBuilder().setColor(THEME.success).setTitle('⚡ Pronto!').setDescription('✅ 5 Cargos de Equipe\n✅ Categoria Tickets\n✅ Canal abrir-ticket\n✅ Canal logs-tickets\n✅ Canal avaliacoes\n✅ Painel com 5 opções!').setFooter({ text: 'NH RP' }).setTimestamp()], components: [backToMainRow()] });
}
