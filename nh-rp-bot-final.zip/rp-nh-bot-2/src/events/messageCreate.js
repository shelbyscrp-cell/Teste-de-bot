const { Events } = require('discord.js');
const { getDatabase, saveDatabase } = require('../database/connection');
const logger = require('../utils/logger');

module.exports = {
    name: Events.MessageCreate,
    async execute(message) {
        if (message.author.bot || !message.guild) return;
        try {
            const db = await getDatabase();
            const config = db.exec('SELECT * FROM security_config WHERE guild_id = ?', [message.guild.id]);
            if (config.length === 0 || config[0].values.length === 0) return;

            const row = config[0].values[0];
            const antiSpam = row[1];
            const spamLimit = row[2] || 5;
            const antiLink = row[3];
            const antiInvite = row[4];

            if (antiSpam) {
                const now = Date.now();
                const cutoff = now - 5000;
                db.run('DELETE FROM anti_spam_cache WHERE guild_id = ? AND timestamp < ?', [message.guild.id, cutoff]);
                db.run('INSERT INTO anti_spam_cache (guild_id, user_id, timestamp) VALUES (?, ?, ?)',
                    [message.guild.id, message.author.id, now]);

                const result = db.exec('SELECT COUNT(*) as c FROM anti_spam_cache WHERE guild_id = ? AND user_id = ? AND timestamp > ?',
                    [message.guild.id, message.author.id, cutoff]);
                const count = result[0].values[0][0];

                if (count > spamLimit) {
                    message.delete().catch(() => {});
                    message.member.timeout(60000, 'Anti-Spam').catch(() => {});
                    logger.warn(`Spam: ${message.author.tag}`);
                }
                saveDatabase();
            }

            if (antiLink && /(https?:\/\/[^\s]+)/g.test(message.content)) {
                message.delete().catch(() => {});
                message.member.timeout(300000, 'Link não autorizado').catch(() => {});
            }

            if (antiInvite && /(discord\.gg|discord\.com\/invite)\/\S+/gi.test(message.content)) {
                message.delete().catch(() => {});
                message.member.timeout(300000, 'Convite não autorizado').catch(() => {});
            }
        } catch (error) {
            logger.error('Erro messageCreate:', error);
        }
    }
};
