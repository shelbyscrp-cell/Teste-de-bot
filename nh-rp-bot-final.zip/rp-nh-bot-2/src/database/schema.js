const { getDatabase } = require('./connection');
const logger = require('../utils/logger');

async function initializeDatabase() {
    const db = await getDatabase();

    const tables = [
        // Configuração do servidor
        `CREATE TABLE IF NOT EXISTS guild_config (
            guild_id TEXT PRIMARY KEY,
            admin_role_id TEXT,
            log_channel_id TEXT,
            transcript_channel_id TEXT,
            rating_channel_id TEXT,
            default_category_id TEXT,
            default_support_role TEXT,
            default_ticket_limit INTEGER DEFAULT 1,
            default_welcome_message TEXT,
            default_close_message TEXT,
            language TEXT DEFAULT 'pt-BR',
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        // Painéis de ticket
        `CREATE TABLE IF NOT EXISTS ticket_panels (
            id TEXT PRIMARY KEY,
            guild_id TEXT NOT NULL,
            name TEXT,
            channel_id TEXT,
            title TEXT DEFAULT '© SUPORTE NH-BOT',
            description TEXT,
            color TEXT DEFAULT '#00FFFF',
            author_name TEXT DEFAULT '©Colt Programmer',
            author_url TEXT,
            author_icon TEXT,
            footer_text TEXT DEFAULT 'Novo Horizonte Roleplay - Todos os Direitos Reservados©',
            footer_icon TEXT,
            thumbnail_url TEXT,
            image_url TEXT DEFAULT 'https://cdn.discordapp.com/attachments/1350922977243304063/1525250927932604487/ChatGPT_Image_9_de_jul._de_2026_18_39_32.png',
            button_emoji TEXT DEFAULT '🎫',
            button_label TEXT DEFAULT 'Abrir Ticket',
            button_style TEXT DEFAULT 'PRIMARY',
            category_id TEXT,
            support_role_id TEXT,
            extra_roles TEXT DEFAULT '',
            ticket_name_format TEXT DEFAULT '{username}',
            ticket_limit INTEGER DEFAULT 1,
            welcome_message TEXT,
            close_message TEXT,
            transcript_channel_id TEXT,
            rating_channel_id TEXT,
            is_active INTEGER DEFAULT 0,
            ticket_type TEXT DEFAULT 'channel',
            topic_channel_id TEXT,
            allow_user_close INTEGER DEFAULT 0,
            auto_close_member_leave INTEGER DEFAULT 0,
            auto_close_inactivity TEXT DEFAULT '',
            limit_one_ticket INTEGER DEFAULT 0,
            notify_staff INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        // Opções de ticket
        `CREATE TABLE IF NOT EXISTS ticket_options (
            id TEXT PRIMARY KEY,
            panel_id TEXT NOT NULL,
            emoji TEXT DEFAULT '💬',
            name TEXT NOT NULL,
            description TEXT,
            sort_order INTEGER DEFAULT 0,
            category_id TEXT,
            support_role_id TEXT,
            welcome_message TEXT,
            close_message TEXT,
            image_url TEXT,
            thumbnail_url TEXT,
            FOREIGN KEY (panel_id) REFERENCES ticket_panels(id) ON DELETE CASCADE
        )`,
        // Tickets ativos
        `CREATE TABLE IF NOT EXISTS active_tickets (
            id TEXT PRIMARY KEY,
            guild_id TEXT NOT NULL,
            panel_id TEXT,
            option_id TEXT,
            channel_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            claimed_by TEXT,
            status TEXT DEFAULT 'open',
            priority TEXT DEFAULT 'normal',
            rating INTEGER,
            rating_feedback TEXT,
            reopen_count INTEGER DEFAULT 0,
            first_response_at DATETIME,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            closed_at DATETIME
        )`,
        // Membros do ticket
        `CREATE TABLE IF NOT EXISTS ticket_members (
            ticket_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            added_by TEXT,
            added_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (ticket_id, user_id)
        )`,
        // Configurações de segurança
        `CREATE TABLE IF NOT EXISTS security_config (
            guild_id TEXT PRIMARY KEY,
            anti_spam_enabled INTEGER DEFAULT 0,
            anti_spam_limit INTEGER DEFAULT 5,
            anti_link_enabled INTEGER DEFAULT 0,
            anti_invite_enabled INTEGER DEFAULT 0,
            trusted_users TEXT DEFAULT '[]',
            ignored_channels TEXT DEFAULT '[]'
        )`,
        // Cache anti-spam
        `CREATE TABLE IF NOT EXISTS anti_spam_cache (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            guild_id TEXT NOT NULL,
            user_id TEXT NOT NULL,
            channel_id TEXT NOT NULL,
            content TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )`,
        // Logs de moderação
        `CREATE TABLE IF NOT EXISTS activity_logs (
            id TEXT PRIMARY KEY,
            guild_id TEXT NOT NULL,
            action TEXT NOT NULL,
            moderator_id TEXT,
            target_id TEXT,
            details TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )`
    ];

    for (const query of tables) {
        db.run(query);
    }

    // Índices para performance
    const indexes = [
        'CREATE INDEX IF NOT EXISTS idx_panels_guild ON ticket_panels(guild_id)',
        'CREATE INDEX IF NOT EXISTS idx_options_panel ON ticket_options(panel_id)',
        'CREATE INDEX IF NOT EXISTS idx_tickets_guild ON active_tickets(guild_id)',
        'CREATE INDEX IF NOT EXISTS idx_tickets_user ON active_tickets(user_id)',
        'CREATE INDEX IF NOT EXISTS idx_tickets_status ON active_tickets(status)',
        'CREATE INDEX IF NOT EXISTS idx_spam_cache_time ON anti_spam_cache(timestamp)'
    ];

    for (const index of indexes) {
        db.run(index);
    }

    logger.info('✅ Banco de dados inicializado com sucesso!');
}

module.exports = { initializeDatabase };
