const initSqlJs = require('sql.js');
const path = require('path');
const fs = require('fs-extra');
const logger = require('../utils/logger');

const dbDir = path.join(process.env.HOME, 'rp-nh-bot-2', 'data');
fs.ensureDirSync(dbDir);
const dbPath = path.join(dbDir, 'rpnh.db');

let db;
let SQL;

async function getDatabase() {
    if (db) return db;
    try {
        SQL = await initSqlJs();
        if (fs.existsSync(dbPath)) {
            const buffer = fs.readFileSync(dbPath);
            db = new SQL.Database(buffer);
            logger.info('📊 Banco carregado');
        } else {
            db = new SQL.Database();
            logger.info('📊 Novo banco criado');
        }
        db.run('PRAGMA foreign_keys = ON');
        return db;
    } catch (error) {
        logger.error('Erro no banco:', error);
        process.exit(1);
    }
}

function saveDatabase() {
    if (db) {
        const data = db.export();
        fs.writeFileSync(dbPath, Buffer.from(data));
    }
}

setInterval(() => saveDatabase(), 30000);
process.on('SIGINT', () => { saveDatabase(); process.exit(0); });

module.exports = { getDatabase, saveDatabase };
